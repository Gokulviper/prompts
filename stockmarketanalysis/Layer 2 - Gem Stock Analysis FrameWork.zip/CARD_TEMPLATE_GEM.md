# DECISION CARD — {TICKER}

> # ⛔ THIS CARD APPLIES ONLY TO {COMPANY NAME} ({TICKER})
>
> **If the question concerns any other ticker, STOP. Do not read further, do not adapt these
> numbers, do not reason by analogy from them.** Every band, threshold, constant and date below is
> {TICKER}-specific and wrong for any other company.

**Type:** Layer 3 knowledge-base card · **Class:** Gem / multibagger · **Pattern:** {G1 | G1-A | G2 | … | hybrid}
**Tier:** {PENNY | MIDCAP} — target **{n}%**, kill floor **{−n}%** · **CIK:** {verified}
**Built:** {date} · ⛔ **STALE-BY: {date}** — {usually one quarter; name the event that forces a rebuild}

---

## ⚠️ {TICKER} — STATUS WARNINGS

⭐ **Every concern the user overrode in Layer 2, with what would prove the override wrong.** Layer 3
states these every session. Write "None" only if there were genuinely no overrides.

| Override | Why it was flagged | ⭐ What would prove the override wrong |
|---|---|---|
| {e.g. Gate 2 rejection overridden} | {evidence horizon exceeds runway} | {specific, dated condition} |

---

## 0. {TICKER} — WHAT THIS CARD IS, AND WHAT IT IS NOT

⭐ **Data, not procedure.** The decision logic lives in the shared engine. ⛔ Cannot run alone.

---

## 1. {TICKER} — ACTIVATION — the card is inert until these are bound

| Slot | Source | If missing |
|---|---|---|
| `current_price` | ⭐ DSIP export or user — ⛔ never search | Ask |
| `avg_cost` · `shares` · `deployed` | DSIP export | ⛔ Ask — the three-input gate |
| `max_budget` · `reserve_remaining` | DSIP export | Ask |
| `today_recommended` | DSIP export | ⛔ Ask before any multiplier |

⚠️ **Past the stale-by date, this card is expired** — refuse to reason from it.

---

## 2. {TICKER} — SURVIVAL

| | Value |
|---|---|
| Burn (operating cash flow, deposits stripped) | {per quarter} |
| Committed funding | {amount, source} |
| Theoretical funding (shelf / ATM) | {amount} — ⚠️ not counted |
| **Runway** | **{n} months** — {arithmetic} |
| ⭐ **The dated wall** | **{date} — {maturity / amortisation / covenant}** |
| Gate 1 verdict | {pass / overridden} |

---

## 3. {TICKER} — FROZEN PARAMETERS

| Parameter | Value | Source & tag |
|---|---|---|
| **Conviction period** | {n} | ⭐ Bounded by runway (§2) — {measured / `[A]`} |
| **Partition length** | {n} | {this stock's simulation / `[A]` placeholder} |
| **Reserve stance** | {user's choice} — context, not instruction | No timing edge found anywhere tested |
| **Multiplier caps** | **Long ≤6× · swing ≤{n}×** · ⛔ dip-side only | Swing cap from **measured single-day demand** / `[A]` |

⛔ **If this stock's simulation hasn't run, every row above is `[A]` — say so plainly.**

---

## 4. {TICKER} — VALUATION BANDS

**Anchor:** {EV ÷ units vs build cost | EV ÷ core revenue | …} — ⭐ chosen because it means
something without earnings.

```
{Show the arithmetic: the disclosed inputs → the anchor → each band edge}
```

| Price | Anchor value | ⭐ What it means in business terms | Band |
|---|---|---|---|
| ${x} | | {e.g. "network valued at its own build cost"} | Extreme bear |
| ${x}–${y} | | | Bear |
| ${y}–${z} | | | Base |
| ${z}+ | | | Bull |

**Basis:** {stated}. ⛔ Re-derive only after an anchor input changes or a C4/C5 thesis change —
never because price moved. ⛔ Never re-derive downward and call the lower price attractive.

---

## 5. {TICKER} — THRESHOLDS

| Rule | Value |
|---|---|
| **Head start fires** | Price ≤ **${threshold}** AND (avg > threshold OR no holdings) — {or OFF} |
| **Head start blocked** | Price above threshold, or avg already at/below it |
| **Single-day trigger** | **>{n}% down** → mandatory cause check |
| **Cumulative trigger** | **~{n}% below** tracker open → same check |
| **Multiplier caps** | See §3 |

⚠️ **The head start is a valuation bet.** ⛔ Never cite the simulation as support. ⭐ With zero
reachable, keep it small or off unless the price is deep.

---

## 6. {TICKER} — CONTROL

| | |
|---|---|
| Major holders / sponsors | {who, board seats, committee chairs} |
| ⭐ Sponsor clock | {fund life / likely exit window, or "none"} |
| Voting structure | {single class / dual-class with the arithmetic} |
| Dilution outlook | {projected share-count change at current price} |
| Return engine | {compounding · structure repair · re-rating · none} — and the exit style it implies |

---

## 7. {TICKER} — EVENT MAP

| # | Date | The yes/no question | What a NO means |
|---|---|---|---|
| ⭐ | **{dated wall from §2}** | {can it be met from operations?} | |
| EV1 | {date} | | |

**Listing-health triggers:** {deficiency notices, cure deadlines, reverse-split votes}
**Undated triggers:** {U1…Un}

---

## 8. {TICKER} — CAUSE TAXONOMY

| Code | For {TICKER}, looks like |
|---|---|
| **C1** Broad selloff | |
| **C2** Sector rotation | |
| **C3** Miss that doesn't matter | |
| **C4** Miss that does | |
| **C5** Structural break (Door B) | |

**Worked example:** {two same-day events pointing opposite ways — classify each, then net}

---

## 9. {TICKER} — SCORECARD REFERENCE

⚠️ Build-date values, not current. **Load-bearing:** {list, highest first}
⭐ **Constructed metric:** {name} = {numerator} ÷ {denominator} ≈ **{value}** — trend: {↑ / ↓}

---

## 10. {TICKER} — FUNDING PROFILE

⭐ **From this stock's own simulation** — ⛔ never the large-cap pooled table.

| Tracker | Peak single day | 21-day demand |
|---|---|---|
| Long | {n}% | {n}% |
| Swing | {n}% | {n}% |

⭐ **Kill-floor margin:** {n} percentage points. {If thin: "Survived through timing, not safety."}

---

## 11. {TICKER} — THE TWO DOORS

**Door A — confirmed:** {list} · **Door B — broken:** {list}
⭐ **Most dangerous combination:** {…}

---

## 12. {TICKER} — STANDING INTERROGATIONS

{I1…In}

---

## 13. {TICKER} — WHAT THIS CARD DROPPED

See the Layer 1 artifact for: {what was compressed out}.

---

## 14. {TICKER} — HONEST LIMITS

- ⛔ No floor beneath an unlimited share count — "already down a lot" is not protection.
- ⭐ Survival and the business were both checked; passing one never saves the other.
- The conviction gate is untestable. One stock is one price path, not a sample.
- {Every `[A]` that matters, and stock-specific limits}
