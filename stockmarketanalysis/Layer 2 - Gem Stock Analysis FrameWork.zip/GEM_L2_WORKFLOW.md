# GEM / MULTIBAGGER · LAYER 2 · WORKFLOW

**Eight steps from a Layer 1 artifact to a decision card.**

⭐ **The rhythm that keeps this from feeling like an interrogation:**
> run the check → **if it passes, say so in one line and keep going** → if something's wrong,
> explain it with the concern library → ask once → move on when he's ready.

Most checks pass. Only failures get paragraphs. End every step with a two-to-three line summary.

---

## STEP 1 — INTAKE, FACT CHECK, PATTERN, TIER

**Goal:** confirm the Layer 1 handoff is correct, current, and classified.

**Input:** the Layer 1 artifact — fact pack, survival/cash, business engine, growth/capture,
management/board, "what would have to be true" with what would kill the thesis, handoff notes.

**Do:**
1. ⛔ **Identity** — ticker → CIK. Hard fact.
2. **Freshness** — any quarter reported since Layer 1 was written? Pull it.
3. **Fact-check load-bearing numbers** — cash, operating cash flow, debt with maturity dates,
   share count and its history. Two sources. Say what changed.
4. **Listing health** — reverse split in the last 12 months · a minimum-bid deficiency notice ·
   going-concern language · delinquent filings. ⭐ The first three are Level 3 concerns; delinquent
   filings mean there is no reliable current data (hard fact 2).
5. **Pattern** — Layer 1 describes; this step names:

| Pattern | In one line |
|---|---|
| **G1** External dislocation | Something outside the company crushed the price; the business is intact |
| **G1-A** Administrative shock | A regulator, payer or agency acted; the impact is quantifiable quickly |
| **G2** Demand wave capture | Contracted demand; the question is execution speed |
| **G3–G5** | Per the Tier-0 spec |
| **First principles** | No named pattern fits — say so |

⚠️ Hybrids exist — EVGO sits between G1-A and G3. Say so rather than forcing one.

6. **Tier** — confirm what the engine assigns (PENNY or MIDCAP) and its constants (target and
   kill floor). ⭐ **Equity as % of enterprise value is a classifier only**, never a signal. If
   negative, the pattern is G4.

**Output:** corrected facts · listing health · pattern · tier with constants.

---

## STEP 2 — SURVIVAL — can it live long enough? *(Gate 1)*

**Goal:** the question everything else depends on. Asked first because a perfect growth story is
worthless if the company runs out of money before it plays out.

**Do:**
1. **Burn = operating cash flow, never net loss.** Last 8 quarters.
2. ⭐ **Strip customer deposits.** Cash customers paid in advance is a loan from the order book —
   it gets called back exactly when orders fall.
3. **Subtract debt due within the year.**
4. **Classify every source of money:**

| Class | Meaning | How much to trust it |
|---|---|---|
| **Committed** | Signed, drawable, conditions met | Count it |
| **Repeat-access** | Raised before on similar terms, no commitment | Count cautiously |
| **Theoretical** | A shelf registration, an ATM, "we have options" | ⚠️ Don't count it |
| **Distressed-structured** | Terms that themselves show capital is expensive | ⚠️ Count it as a warning |

5. **Runway in months** — with the arithmetic shown.
6. ⭐ **Find the real wall.** Often it isn't today's cash but a dated event — a maturity, a
   covenant test, an amortisation start. *(EVGO: the DOE principal amortisation starting 2030-03
   — ~$62–64M/yr on the reduced facility — before the earliest profitability estimate of 2031.)*

**If it passes:** one line — *"Runway ~X months to the Y wall; committed funding covers it."*
**If not:** Level 3 — the runway is shorter than the thesis needs.

**Output:** runway with arithmetic · financing table · the dated wall · verdict.

---

## STEP 3 — THE BUSINESS — is the lost value coming back? *(Gate 2)*

**Goal:** separate "temporarily delayed" from "gone for good."

**Do:**
1. **Unit economics** — name the unit (per stall, per seat, per customer). Cost to serve, revenue
   per unit, and ⭐ **the trend per unit — this is usually the whole answer.**
2. ⭐ **The constructed metric** — the number management doesn't headline but that shows whether
   growth is real. *(EVGO: throughput per stall per day. Stalls grew faster than usage, so the
   per-stall figure fell.)* If Layer 1 didn't find one, build one. If none exists, say so.
3. **Revenue quality** — is some revenue lower-margin or one-off, inflating growth? Separate it.
4. **Operating leverage** — present, arriving, or structurally blocked? ⭐ Some businesses can't
   cost-cut their way to profit; they can only be *used* more.
5. **Bottom-up ceiling** — countable units × realistic price × realistic share. ⛔ Never a
   top-down market-size figure.
6. **Absurdity test at five years** — state the implied position and ask if it's absurd. ⭐ A
   ceiling that isn't absurd but contradicts the current trend is the most useful result — that
   contradiction *is* the thesis.
7. ⭐⭐ **The rejection check:** when would the evidence that settles the thesis arrive — and is
   that *before* the runway from Step 2 runs out?

**If the evidence arrives after the runway ends:** Level 3 — the framework's hard rejection. Make
the case properly. If he overrides, record it with **what would prove the override wrong** — as
the EVGO card does.

**Output:** unit table · constructed metric and trend · ceiling and absurdity test · rejection
check verdict.

---

## STEP 4 — CAPTURE AND CONTROL — does the shareholder get paid? *(Gate 3 + board)*

**Goal:** the company surviving and **you** being paid are different questions.

**Do:**
1. **Funding gap** = capital needed to reach the thesis − committed capital. Arithmetic shown.
2. ⭐ **Dilution forecast** — how much must be raised, and at roughly today's price, how many new
   shares? ⚠️ Dilution hurts most at the lowest price — exactly when a struggling company needs
   money.
3. ⚠️ **Dilution and expropriation are different** — new shares diluting you vs a controlling
   holder taking value directly (a squeeze-out, a take-private below value). Check both separately.
4. **Who controls the outcome:**
   - Sponsors or PE owners — ⭐ **a fund has a lifespan; that's a clock on the company that no
     filing states.** *(EVGO: LS Power holds four board seats incl. the Comp Committee chair.)*
   - Dual-class shares — if insiders' votes outnumber yours, say so plainly
   - Pay structure — what is management actually paid to achieve?
   - Behaviour vs promises — what did they say, what did they do?
5. **Management actions** — table of financings, debt moves, asset sales, hires and exits: which
   way the cash moved, and whether it put anyone ahead of common shareholders. ⛔ Never a score.
6. ⭐ **Return engine** — forecast which one this is, because it decides *how* to exit later:

| Engine | What it implies |
|---|---|
| Business compounding | Hold; sell late or never |
| Capital-structure repair | Hold until the balance sheet is fixed, then exit |
| Multiple / policy re-rating | ⭐ Exit when the reason reverses — it can undo itself |
| No engine | Dated checkpoints; exit on the first failure |

**Output:** funding gap · dilution arithmetic · control map · actions table · return engine.

---

## STEP 5 — BULL / BASE / BEAR RANGES

**Goal:** price ranges built from the business outward.

**Do:**
1. ⭐ **Choose an anchor that means something without earnings.** Most gems have none.

| Anchor | Good when | Watch out |
|---|---|---|
| **Enterprise value ÷ units vs build cost** | Countable physical assets | Ignores whether the units are used |
| **EV ÷ core revenue** | Low-margin revenue inflates the total | Needs the split disclosed |
| **EV ÷ forward recurring EBITDA** | Near profitability | ⚠️ Explodes when EBITDA is near zero |
| **Forward EPS / FCF** | Genuinely profitable | Rare here |

⭐ **The EVGO model:** below ~$1.22, the market valued the network at *less than it cost to
build* (~$90,000 per stall). A band that means something in business terms, recomputable from two
disclosed numbers.

2. **State the basis** of every multiple.
3. **Scenarios, working backwards** — what the business must deliver → plausible? → implied range.
4. **Bands** with business meaning, not just prices. **Where today's price sits.**

**Output:** anchor with arithmetic · scenario table · band table · today's position.

---

## STEP 6 — THE STOCK'S OWN SIMULATION

**Goal:** set tracker parameters from this stock's own price history. ⛔ The large-cap pooled
study does not apply — gem price behaviour is too individual.

**Do:** follow `GEM_SIMULATION_GUIDE.md` — design the batch, pre-register the rules, run it in
Claude Code, read the synthesis. Then set:

| Parameter | Rule for gems |
|---|---|
| **Conviction period** | ⭐ **Bounded by runway** from Step 2 — the opposite of large caps, where evidence arrival sets it |
| **Partition length** | From the simulation |
| **Multiplier caps** | Long ≤6×. Swing from this stock's measured funding demand — ⚠️ often much lower |
| **Head-start threshold** | A business-meaningful band edge from Step 5. ⭐ With zero reachable, the honest default is small or off unless the price is deep |
| **Reserve** | His decision — no timing edge exists anywhere tested |

⚠️ **If the simulation hasn't been run:** mark every parameter `[A]` — placeholder, not settled.
⛔ Never present a placeholder as a finding.

**Output:** parameter table with source and tag · funding profile · kill-switch margin.

---

## STEP 7 — EVENT ROADMAP

**Do:**
1. ⭐ **Convert Layer 1's conditions** — each "what would have to be true" → a dated yes/no
   checkpoint; each "what would kill the thesis" → a Door B entry and a C5 example.
2. ⭐⭐ **The dated structural gate gets its own row** — the maturity wall, amortisation start, or
   covenant test from Step 2. It's usually the most important row on the map.
3. **Listing-health triggers** — deficiency notices, cure deadlines, reverse-split votes.
4. **The quarterly filing** as its own row, separate from the call.
5. **Cause taxonomy** — what C1–C5 look like for *this* stock, with one worked example where two
   same-day events point opposite ways.
6. **Two doors**, and the most dangerous *combination*.

⛔ "Q3 results" is not a checkpoint. "Does throughput per stall rise year over year in Q3?" is.

**Output:** event map · triggers · cause taxonomy · two doors.

---

## STEP 8 — DECISION CARD

Fill `CARD_TEMPLATE_GEM.md`. **Checklist before finalising:**
- [ ] Retrieval guard is the first thing in the file
- [ ] ⭐ Ticker in every section heading
- [ ] All twelve standard headings, plus the gem-only survival and control sections
- [ ] Tier constants stated (target and kill floor)
- [ ] Explicit multiplier caps
- [ ] Stale-by date — ⚠️ gems go stale faster; one quarter is often right
- [ ] Every multiple's basis stated
- [ ] Simulation parameters tagged — measured, or `[A]` placeholder
- [ ] ⭐ **Every override recorded as a status warning at the top, with what would prove it wrong**
- [ ] No position, split, or amount in the card

**Output:** `CARD_{TICKER}.md`, then three lines on what makes it differ from the samples.
