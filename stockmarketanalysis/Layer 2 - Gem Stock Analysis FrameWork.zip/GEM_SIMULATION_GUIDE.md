# GEM SIMULATION GUIDE — designing a stock's own simulation wave

**Used in Step 6.** Gems get their own simulation because their price behaviour is too individual
for the large-cap pooled study. This guide carries everything learned from the ORCL and EVGO runs,
so nobody rediscovers the traps.

⭐ **Explain it to the user in one line first:** *"We'll replay your plan against this stock's
real past prices to see which settings hold up — it can't tell us whether the company is good,
only how the deployment schedule behaves on this particular stock."*

---

## 1. WHAT A SIMULATION CAN AND CANNOT TELL YOU

**Can:** which partition length suits this stock · how much money the trackers demand in a single
day · how close the plan came to the kill floor · whether DSIP beats simply spreading money
evenly.

⛔ **Cannot:** whether to buy · whether the thesis is right · what the price will do next · the
"best" settings in any forward sense. One stock is one price path — a story, not a sample.

⭐ **Always compare against a naive baseline** — the same money spread evenly over the same days.
In ORCL's first wave, DSIP *lost* to plain even spreading in 4 of 6 short windows. Without the
baseline, that would have looked like success.

---

## 2. ⛔ ENGINE FACTS — settled, do not re-test

| Fact | Consequence |
|---|---|
| **Deployment is linear in capital** (0.0156% deviation) | Splits are computed with arithmetic. ⛔ Never simulate a split sweep |
| **The random seed is fixed by date and price move** | Same stock + same start date = identical output. ⭐ Variation comes from *different dates*, never from seed labels |
| **Deployment style has no effect on single-partition trackers** | ⛔ No style axis on swing rows — it adds rows and zero information |
| **Swing tracker = conviction ≤ 25 trading days** | One partition only, no SUCCESS possible, ends by kill or capital exhaustion |
| **Kill decisions use partition-level returns** | The CSV's profit column is tracker-wide — a different number. ⭐ Recompute; don't read the column |
| **Capital is hardcoded at $100,000 per row** | The CSV's capital column is cosmetic |
| **Fractional-share setting is inert** | Results don't transfer to builds where rounding binds |
| **Engine price bars can differ from outside feeds** | Internally consistent; ⛔ never compare absolute prices across sources |
| **The engine has no CIK field** | Verify identity outside the engine |

---

## 3. ⛔ HALT GATES — check before the first run

1. **Mapper** — confirm day-suffixed values (`126D`, `5D`) map to days on **both** the duration
   and partition columns. A `5D` read as `5M` turns every row into a long tracker.
2. **Tier** — confirm the stock pins to the right tier (PENNY or MIDCAP) before and after.
3. **Identity** — CIK verified outside the engine.
4. **Data** — no splits inside windows (or correctly adjusted); every window closes inside the
   available price history; record dropped rows *before* seeing results.
5. **Contamination** — ⛔ never read `pythonAnalysis.formulaInsights`; it scans the whole shared
   reports folder and has cited unrelated stocks. Clear or isolate `docs/reports/` first.

---

## 4. DESIGNING THE WAVE

### 4.1 The horizon — bounded by the runway
⭐ **For gems, the conviction period cannot exceed the funded runway from Step 2.** Derive it and
write it down *before* running. *(Large caps are the opposite — there the evidence schedule sets
it.)*

### 4.2 Regime breaks — the most common hidden trap
Look for the day the stock's behaviour changed — a major disclosure, a financing, a listing event.
⭐ **If one exists, split the history at it and never pool the two halves.**

*ORCL lesson:* one disclosure turned an enterprise-software stock into an AI-infrastructure proxy
overnight. Pooling before and after would have averaged two different companies. The two halves
also disagreed — and **the half matching today's company governs.**

### 4.3 Anchors — dates, never prices
Six start dates per stratum, set by a calendar rule written in advance. ⛔ Never anchored on the
user's own entry price or date.

### 4.4 The arms

| Arm | Question | Rows |
|---|---|---|
| **Baseline** | Which partition length and style suit this stock? | 6 anchors × 5 partition lengths × 3 styles |
| **Naive baseline** | Does DSIP beat even spreading? | ⭐ Computed from prices, not simulated |
| **Event vs placebo** *(optional)* | Does deploying at an event beat a random day? | Event dates, each paired with a random day **from the same regime** |

⚠️ **Placebos must come from the same regime as the events.** A placebo drawn from a calmer era
compares regimes, not events.

⭐ **Prior expectation, stated honestly:** every timing trigger tested in this project has failed
against placebo (pooled p ≈ 0.64). A null event result is the expected result and still worth
reporting.

### 4.5 ⭐ Pre-register the selection rule — before running
Write down *now* how the result will be read: which partition length wins, how ties break, what
happens if strata disagree. Stated before the run, it's a rule. Stated after, it's a choice made
with the answer visible.

---

## 5. THE CLAUDE CODE RUN PROMPT

Layer 2 writes a stock-specific run prompt for Claude Code. It must contain:

1. **The one question** the batch exists to answer
2. **What it can't answer**, and any direction already known from the price path
3. **Halt gates** (section 3), each a hard stop
4. **The strata** and the pooling ban, if a regime break exists
5. **The derived horizon**, with its arithmetic
6. **The frozen window rule** and **the pre-registered selection rule**
7. **Run order:** baseline → recompute from raw
8. **What the synthesis must contain** (section 6) and ⛔ what it must never contain
9. **Honest limits**, reproduced verbatim

⭐ The ORCL wave prompts are the worked examples of this structure.

---

## 6. WHAT THE SYNTHESIS MUST REPORT

⛔ Recompute from the raw per-day files. Never trust the batch's own summary report for a headline
number — cross-check it and report every discrepancy.

1. Run metadata — date, commit, settings, rows attempted / succeeded / failed
2. **DSIP vs the naive baseline**, per anchor
3. **Converged partition length per anchor, with dispersion** — ⭐ wide disagreement *is* the
   finding
4. **Style ranking by three aggregation methods** (mean, median, value-weighted). If they
   disagree, the ranking isn't robust
5. **Completed partitions with their end reason**, one row each
6. ⭐ **Peak single-day and 21-day deployment**, long vs swing — the affordability input
7. ⭐ **Kill-floor margin** — how close the plan came
8. **Entry-timing spread vs configuration spread** — how much the start date mattered compared
   with every setting

---

## 7. WHAT GOES ON THE CARD

| Card field | From the synthesis |
|---|---|
| Conviction period | Derived horizon, ≤ runway |
| Partition length | Converged value, with its dispersion |
| ⭐ Swing multiplier cap | **From measured single-day demand** |
| Funding profile | Peak day and 21-day, long vs swing |
| Kill-floor margin | As measured — with a warning if thin |

**⭐ The EVGO example, worth showing a beginner:**
- A swing tracker's worst single day demanded **26.6% of its entire bucket**, against the long
  tracker's **0.76%** — about **35× more cash on one day.** That's why EVGO's swing cap is 2×.
- The plan came within **0.17 percentage points** of the kill floor. It survived through window
  timing, not safety. ⛔ **A kill switch that didn't fire is not a sign the stock is safe.**
- Start date mattered about **25× more** than deployment style. Every dial is small next to when
  you begin.

---

## 8. IF THE SIMULATION CAN'T BE RUN

Say so plainly. Mark conviction, partition, caps and funding profile as `[A]` placeholders. ⛔
Never present a placeholder as a finding, and never borrow another stock's measured numbers to
fill the gap.
