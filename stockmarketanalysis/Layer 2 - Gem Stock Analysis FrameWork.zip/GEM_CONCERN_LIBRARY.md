# CONCERN LIBRARY — gem / multibagger

**How to explain a worry so a beginner genuinely understands it — then let him decide.**

Every entry: **level** · what it is · an everyday example · the real number · what to ask · what
to record on the card if he proceeds.

⭐ **Rules for using this file**
- Match your words to the level. Most checks pass — say so in one line and move on.
- ⭐ **The analogy explains; the number proves.** Always tie the example back to the real figure.
- ⛔ Never use an example that makes the risk sound smaller or bigger than the number shows.
- Explain once. Don't repeat an answered concern unless the evidence changed.
- Adapt the example to the business. The lemonade stand is a default, not a rule.

---

## ⭐ TEACHING NOTE — why we check survival AND the business, every time

Explain this once, early, in plain words. It's the reason the gem checks exist.

> Two companies in the exemplar library show why. **CARA** had plenty of money to survive — but
> its business didn't recover. **SGMO** had a business that could have worked — but ran out of
> money first. **Both went to roughly zero.**
>
> A check that only asks "will it survive?" would have approved CARA. A check that only asks "is
> the business good?" would have approved SGMO. That's why we ask both, always.

**Example:** a restaurant needs both a good chef *and* enough cash to pay rent until the reviews
come in. A great chef with three weeks of cash closes. A full bank account with bad food closes
too — just slower.

---

# ⛔ LEVEL 3 — make the case against

Argue it properly: *"This doesn't look good, and here's why… Unless you have something I'm
missing, I don't think it's a good idea to go further."* If he still proceeds, respect it and
record it at the top of the card — ⭐ **with what would prove the override wrong.**

---

## G3.1 — The money runs out before the plan can work *(Gate 1)*

**Example:** running a marathon with enough water for twenty miles. You might be the fastest
runner in the race — it won't matter at mile twenty-one.

**Tie back to:** Step 2's runway in months, against when the thesis needs to have paid off.

**Ask:** *"The runway ends before the business can prove itself. Unless you see funding I've
missed, the thesis may never get the chance to be right. Still want to continue?"*

**Record if overridden:** ⚠️ *Runway ({n} months) shorter than the thesis timeline. Proceeds on
the assumption of new funding.* **Would prove it wrong:** {no committed funding by {date}}.

---

## G3.2 — The proof arrives after the money is gone *(Gate 2 — the hard rejection)*

**What it is:** the evidence that would show the thesis is right lands *after* the runway ends.
The framework's rule: then the stock isn't investable at any price — you'd be paying for a
result you can't wait to see.

**Example:** a boat heading for an island, but the fuel runs out before the island is even in
sight. It doesn't matter how good the island is.

**Real case — EVGO:** the DOE loan starts requiring principal repayments in **March 2030**
(~$62–64M a year on the reduced facility), while the earliest estimate for real profitability is
**2031**. The bill arrives before the proof.

**Ask:** *"By the framework's own rule, this fails. What would you need to see to believe the
money lasts long enough?"*

**Record if overridden:** ⚠️ *Evidence horizon exceeds funded runway — framework rejection
overridden by user.* **Would prove it wrong:** {the specific condition}. *(EVGO's card is the
model — its Gate 0 override carries exact falsification conditions.)*

---

## G3.3 — New shares eat the gains *(Gate 3)*

**What it is:** a small company short of money sells new shares. The business may grow, but your
slice of it shrinks — and it happens most at the worst moment, because a low price means issuing
far more shares to raise the same money.

**Example:** a bakery bakes a bigger pizza but cuts it into many more slices. Worse: it has to cut
the most slices exactly when the pizza is smallest.

**Tie back to:** Step 4's dilution arithmetic — funding gap ÷ today's price = new shares, then
the new share count ÷ old share count.

**Ask:** *"Even if the business works, raising what it needs at today's price would roughly
{multiply} the share count. Are you comfortable with that?"*

**Record if overridden:** ⚠️ *Projected dilution of ~{n}× at current price.*

---

## G3.4 — The key number is moving the wrong way

**What it is:** the one per-unit number that shows whether the business works is getting worse,
not better.

**Example:** a café adds tables faster than it gains customers. Total customers go up, so it
*looks* like growth — but each table sits emptier than before.

**Real case — EVGO:** stall count grew faster than charging usage, so **throughput per stall per
day fell.** Total revenue grew; the thing the thesis depends on shrank.

**Ask:** *"The number the whole thesis rests on is going the wrong way. What would turn it?"*

**Record if overridden:** ⚠️ *Constructed metric deteriorating at build date.* **Would prove it
wrong:** {the metric failing to rise by {checkpoint}}.

---

## G3.5 — The auditor or the exchange is already raising the alarm

**What it is:** going-concern language (the auditor doubts the company survives 12 months), a
minimum-bid deficiency notice, or a recent reverse split.

**Example:** a reverse split is like swapping ten $1 notes for one $10 note — the same money on
paper. But companies usually do it because the price fell too low to stay listed, and the price
often keeps falling afterward.

**Why it's serious:** these are the company's own referees — its auditor or its exchange —
flagging trouble on the record. A going-concern note means the auditor doubts the company lasts
twelve months. A reverse split usually means the price fell too low to stay listed. ⭐ Keep them
separate from the business question: a company can fix its listing without fixing its business,
and a reverse split is a share-structure event, not a recovery.

**Ask:** *"People whose job is to check this company are already worried. What do you see that
they don't?"*

**Record if overridden:** ⚠️ *{Going concern / deficiency notice / reverse split} active at build
date.*

---

# LEVEL 2 — explain, then ask once

Plain words, tie to the number, one question. **If he's comfortable, proceed** and note it.

---

## G2.1 — Customer deposits make the cash look better than it is

**Example:** a caterer paid in advance for next month's weddings looks cash-rich. But that money
is already spoken for — and if bookings drop, it vanishes fast while the costs don't.

**Tie back to:** Step 2 — burn recalculated with deposits stripped out.

**Ask:** *"Without the deposits, the runway is {n} months, not {m}. Does that change your view?"*

---

## G2.2 — The funding is "possible," not "promised"

**Example:** "I could always borrow from my uncle" isn't money in the bank. A shelf registration
or an ATM programme means the company *can* sell shares — not that anyone will buy them at a
good price.

**Tie back to:** Step 2's financing table — how much is committed vs theoretical.

**Ask:** *"Only {x} of the funding is actually committed. Comfortable relying on the rest?"*

---

## G2.3 — A big owner is running on their own clock

**Example:** a landlord planning to sell the building in three years. Your lease is fine until
then — but their timeline isn't yours, and they'll decide what suits them.

**Real case — EVGO:** LS Power holds four board seats, including the chair of the Compensation
Committee. A private-equity fund has a fixed life, and its exit may not line up with the thesis.

**Ask:** *"Does the thesis need longer than this owner is likely to wait?"*

---

## G2.4 — "Breakeven" that came from a one-off

**Example:** a shop that "broke even" the month it sold its old delivery van. It didn't — it
cashed in something it can't sell twice.

**Tie back to:** Step 3 — strip one-off items and recompute the milestone.

**Ask:** *"Take out the one-time item and it's not breakeven. Does the thesis still hold?"*

---

## G2.5 — Growth inflated by a different, weaker business

**Example:** a café counts its catering jobs as café sales. Revenue looks great — but catering
earns thin margins and isn't the business you're betting on.

**Real case — EVGO:** non-charging revenue (building chargers for others) was roughly **half** of
Q1 revenue — so headline growth overstated the core charging business.

**Ask:** *"Should we judge it on the core revenue line instead?"*

---

## G2.6 — Signed isn't paid

**The ladder:** memorandum → letter of intent → framework → signed → funded → in reported
revenue. ⭐ Every step up is real progress; only the last one is money.

**Example:** a customer promising to order is not an order; an order is not a payment.

**Ask:** *"Which of these deals is actually on the last rung?"*

---

## G2.7 — Insiders out-vote you

**Example:** you join a club as a member, but the founders hold ten votes each. You can voice an
opinion; you can't outvote them.

**Tie back to:** Step 4 — dual-class arithmetic.

**Ask:** *"If insiders' interests and yours ever split, they decide. Comfortable with that?"*

---

# RETIRED REASONING — correct gently, at Level 2

These sound sensible and have been tested wrong. Correct once, with the evidence.

| Belief | Why it's wrong |
|---|---|
| **"Insiders are buying, so it's safe"** — or *"no insider buying, so avoid"* | Insider buying was **absent in 21 of 21** winners in the library. It isn't a requirement, and its presence isn't proof |
| **"Big smart investors are in, that's a floor"** | Sophisticated capital as a price floor went **0 for 7** |
| **"It's down 90%, it can't fall much more"** | ⭐ There's **no floor beneath an unlimited share count.** A company can keep issuing shares |
| **"It hit the kill switch, the company's failing"** | Two stocks **0.36pp** apart on the kill measure went **+1,087%** and **−99.49%**. *(EVGO came within **0.17pp** of its kill floor — that was window timing, not safety)* |
| **"SYM / ASTS show this setup works"** | Both are **unresolved**. They show *how* to analyse, never *what happens* |
| **"Same setup as Antero, which went 46×"** | ⭐ The same entry signature produced **total losses** in same-sector peers in the same window. The library remembers the winner |

---

# LEVEL 1 — note in one line, carry on

| Situation | One-line note |
|---|---|
| A check passes | "Survival: ~X months of committed runway. Fine." |
| Analyst downgrade | "An opinion, not new evidence." |
| A volatile week | "The price moved; the business didn't." |
| A partnership announcement | "Which rung is it on? Announced isn't signed, signed isn't paid." |
| An upbeat executive interview | "Words, not numbers. Wait for the filing." |

---

## ⭐ THE TEST OF A GOOD EXPLANATION

After you explain, he should be able to say the concern back in one sentence of his own. If he
can't, try a different example. ⛔ Don't repeat the same one louder.
