# LAYER 1 — SHAREABLE BRIEF (FINAL FORMAT)

## PURPOSE

The shareable brief is a fast triage and collaboration artifact.

It is NOT:
- a miniature valuation report;
- a buy/sell recommendation;
- a final verdict;
- a ranking;
- a score.

Its purpose is:

> Give another student enough context to understand the case, challenge it, and contribute useful research without reading the full artifact.

---

# TEMPLATE

## COMPANY

**Company:**  
**Ticker:**  
**Category:**  
**Recommended research priority:**  
**Core question:**

One sentence describing the question the full research must resolve.

---

## 1. WHAT THE BUSINESS DOES

2–5 plain-language sentences.

Who pays, what they buy, and how the company makes money.

---

## 2. WHY THIS CASE MATTERS NOW

The specific current event/change/repricing that makes this worth researching.

Use dated facts.

---

## 3. POSITIVE ANCHOR POINTS

These are not “pros” in the casual sense.

They are concrete mechanisms that could materially improve the business or make the thesis work.

For each:

### Anchor A — [specific mechanism]
- What could happen?
- Why could it matter?
- What evidence already exists?
- What still needs verification?

Use falsifiable research questions.

Example for Uber:
> Autonomous transportation could change the supply side of Mobility. The key question is whether Uber can participate in autonomous trips through fleet/platform relationships while retaining valuable demand-side economics.

Do NOT write:
> “Robotaxis will make Uber huge.”

---

## 4. NEGATIVE ANCHOR POINTS

These are concrete mechanisms that could prevent the thesis from working.

For each:
### Anchor B — [specific threat]
- What could go wrong?
- Why could it matter?
- What evidence exists?
- What needs verification?

---

## 5. WHAT WOULD HAVE TO BE TRUE?

3–6 concise conditions.

Example:
- Condition 1
- Condition 2
- Condition 3

Each must describe a business condition, not a stock-price condition.

---

## 6. KEY QUESTIONS FOR OTHER STUDENTS

List the highest-value unresolved questions.

These should make collaboration easy.

---

## 7. QUICK FACTS

Only the most useful facts:
- latest revenue direction;
- operating direction;
- major current catalyst;
- major financial/capital fact;
- relevant category-specific fact.

Tag every figure.

---

## 8. WHAT WOULD KILL THE CASE?

The strongest factual development that would invalidate the central business thesis.

Do not use price alone.

---

## 9. RESEARCH HANDOFF

State:
- what has been established;
- what is still unknown;
- which question the next researcher should attack first.

---

## LANGUAGE RULE

Use:
- “could”
- “if”
- “requires”
- “question to test”
- “evidence suggests”
- “management claims”

Avoid presenting hypotheses as facts.

The brief should be useful for discussion, disagreement, and rapid filtering.
