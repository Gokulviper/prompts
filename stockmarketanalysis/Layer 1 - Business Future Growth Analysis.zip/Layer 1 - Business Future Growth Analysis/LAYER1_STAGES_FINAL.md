# LAYER 1 — STAGE ARCHITECTURE (FINAL HIGH-LEVEL SPEC)

## GLOBAL RULE

Every stage has one job.

Do not duplicate work unnecessarily.
Do not answer the next stage's central question early.
At every stage apply the satisfaction gate.

---

# CATEGORY 1 — LARGE-CAP LOSER

## STAGE 0 — BASELINE / FACT PACK

Purpose:
Establish the business and factual operating baseline before interpretation.

Cover:
- what the company sells;
- who pays;
- unit of sale;
- revenue streams;
- business model;
- 8–12 quarters of financial history;
- revenue, gross profit or clearly labeled proxy, operating income, net income, OCF, capex, cash;
- QoQ and YoY revenue growth;
- headcount;
- major cost lines;
- rigid/flexible cost characterization;
- true cost of doing business;
- current business condition;
- dated decline timeline;
- company-specific vs sector/macro events.

Output is description first. Judgement is deferred.

## STAGE 1 — WHY IT FELL

Purpose:
Reconstruct the repricing.

Cover:
- dated catalysts;
- earnings/guidance changes;
- demand deterioration;
- execution problems;
- competitive changes;
- technology disruption;
- regulation;
- macro/sector effects;
- management events;
- capital allocation where relevant.

Separate:
- what objectively changed;
- what the market appears to have reacted to;
- what is temporary;
- what may be structural.

Core question:
> What actually caused the repricing?

## STAGE 2 — COMPETITIVE POSITION / ROUTE BACK

Purpose:
Resolve the Category 1 hard question.

Cover:
- competitors;
- market position;
- switching costs;
- network effects;
- pricing power;
- product strength;
- customer behavior;
- distribution;
- technological disruption;
- structural advantages/disadvantages;
- evidence of strengthening or weakening;
- plausible routes to regain lost ground.

Core question:
> Is the competitive position intact enough to support meaningful enlargement?

Do not convert this into valuation.

## STAGE 3 — WHAT WOULD HAVE TO BE TRUE

Purpose:
Translate the research into explicit conditions.

For each condition:
- what must happen;
- evidence supporting it;
- evidence against it;
- what remains unknown;
- what would prove it wrong.

Then apply the satisfaction gate.

Final output:
- full Layer 1 artifact;
- shareable brief;
- handoff notes for Layer 2.

---

# CATEGORY 2 — GEM / MULTIBAGGER

## STAGE 0 — BASELINE / FACT PACK

Establish:
- business;
- customer;
- revenue model;
- unit economics shape;
- financial history;
- cash;
- costs;
- capital structure basics;
- management;
- current situation;
- growth vectors visible from the business.

Do not yet decide whether it survives or captures the opportunity.

## STAGE 1 — SURVIVAL / CASH

Purpose:
Determine whether the company can survive long enough for the thesis to play out.

Cover:
- cash;
- OCF;
- burn;
- financing;
- maturities;
- dilution;
- working capital;
- customer deposits;
- capital raises;
- financing quality;
- going-concern/restructuring signals.

Do not compute downstream gates or deployment metrics.

Core question:
> Can it survive long enough for the business thesis to play out?

## STAGE 2 — BUSINESS ENGINE

Purpose:
Understand what actually drives the business.

Cover:
- revenue drivers;
- customers;
- acquisition;
- retention;
- repeat behavior;
- unit economics shape;
- operating leverage;
- scalability;
- whether growth is genuine or funding-driven.

Core question:
> What is the engine that can make this business materially larger?

## STAGE 3 — GROWTH / CAPTURE

Purpose:
Identify countable growth vectors.

Cover:
- core expansion;
- product expansion;
- geography;
- adjacency;
- customer expansion;
- market-share capture.

Use bottom-up, countable mechanisms.

Never use a top-down TAM as a ceiling.

Core question:
> How can the company actually capture enough growth to become meaningfully larger?

## STAGE 4 — MANAGEMENT / BOARD / CAPITAL ALLOCATION

Purpose:
Understand who controls the outcome and how capital decisions have behaved.

Cover:
- board;
- incentives;
- founders/sponsors;
- ownership;
- capital allocation;
- dilution;
- financing history;
- related parties;
- governance;
- behavior versus stated promises.

Do not compress behavior into a score.

Core question:
> Who actually controls the outcome, and what has their behavior demonstrated?

## STAGE 5 — WHAT WOULD HAVE TO BE TRUE

Combine:
- survival;
- business engine;
- growth;
- capture;
- management behavior.

Specify:
- necessary conditions;
- supporting evidence;
- contradictions;
- unresolved questions;
- what would kill the thesis.

Then satisfaction gate.

Output:
- full Layer 1 artifact;
- shareable brief;
- Layer 2 handoff.

---

# CATEGORY 3 — SUB-$1 SWING

This framework is provisional and intentionally short.

## STAGE 0 — $1 HISTORY / LISTING SITUATION

Purpose:
Understand how and why the company is below $1.

Cover:
- whether it has previously traded above $1;
- first entry below $1;
- every material prior sub-$1 episode;
- whether it recovered;
- what caused each recovery;
- genuine operating recovery versus reverse split/share-structure event;
- Nasdaq minimum-bid compliance;
- deficiency notices;
- reverse splits;
- share-count evolution;
- dilution;
- financing history;
- debt/maturities;
- survival situation;
- current reason for being below $1.

Core question:
> Has this company demonstrated a genuine business-driven route back above $1 before?

## STAGE 1 — OPERATING IMPROVEMENT PATH

Purpose:
Identify concrete operating levers that could improve the business.

Cover:
- revenue improvement;
- gross-margin improvement;
- operating-expense reduction;
- headcount changes;
- restructuring;
- pricing;
- customer growth;
- contracts;
- product changes;
- operating leverage;
- financing constraints.

Explicitly separate:

A. business-driven route above $1  
B. share-structure route above $1

Core question:
> What concrete operating changes could materially improve the business, and has management demonstrated the ability to execute them?

Do not invent later Category 3 stages yet.

---

# SATISFACTION GATE

At every category/stage:

> Are you satisfied this business can become meaningfully larger, and do you understand how?

If no/hedge:
STOP.

Never persuade the user.
