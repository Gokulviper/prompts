# DECISION CARD — ORCL

> # ⛔ THIS CARD APPLIES ONLY TO ORACLE CORPORATION (ORCL)
>
> **If the question concerns any other ticker, STOP. Do not read further, do not adapt these
> numbers, do not reason by analogy from them.** Every band, threshold and date below is
> ORCL-specific and wrong for any other company. Say which ticker you need and stop.

**Type:** Layer 3 knowledge-base card · **Class:** Large-cap loser, **stratum S2** (capital
intensity / balance sheet)
**Built:** 2026-09-18 · ⛔ **STALE-BY: 2027-03-31**

---

## 0. ORCL — WHAT THIS CARD IS, AND WHAT IT IS NOT

⭐ **This card is data, not procedure.** It contains no decision tree, no routing, no arithmetic
rules, no output format. Those live in the **shared Decision Engine**, which is the same file for
every stock.

**Engine + this card = a complete ORCL session.** Neither works alone.

⛔ **This card cannot be executed on its own.** If the Decision Engine is not loaded, say so and
stop rather than improvising a procedure from the contents below.

---

## 1. ORCL — ⭐ ACTIVATION — the card is inert until these are bound

**Every value below comes from the DSIP portfolio metadata block the user pastes, or from the
user directly. ⛔ None of them may be assumed, remembered, carried from an earlier session, or
sourced from a web search.**

| Slot | Source | If missing |
|---|---|---|
| `current_price` | ⭐ User-confirmed or DSIP block | ⛔ **Ask. Never search for it.** Search snapshots lag intraday by hours |
| `avg_cost` | DSIP block | ⛔ Ask |
| `shares` | DSIP block | ⛔ Ask |
| `deployed` | DSIP block | ⛔ Ask |
| `max_budget` | DSIP block | ⛔ Ask |
| `reserve_remaining` | DSIP block | ⛔ Ask |
| `conviction_period` | DSIP block | Default §2 if absent, **and say so** |
| `today_recommended_amount` | DSIP block | ⛔ Ask before suggesting any multiplier |
| `partition_no`, `days_elapsed`, `days_expected` | DSIP block | Optional — context only |

⛔ **The three-input gate:** no recommendation of any kind without `avg_cost`, `shares` and
`deployed` current as of today. They drift daily.

⚠️ **If today's date is after the stale-by date above, this card is expired.** ⛔ Say so and
refuse to reason from it. Bands and event dates need rebuilding, not patching.

---

## 2. ORCL — FROZEN PARAMETERS

| Parameter | Value | Source |
|---|---|---|
| **Conviction period** | **2 years (504 trading days)** | Derived from the event map; ORCL waves showed 126d loses to naive deployment 4 of 6 anchors, 504d wins 6 of 6 |
| **Partition seed** | **9 months** (partition 1 only; adapts to ~50–65 td after) | R2 edge peaked at 9M/12M, tied; 9M chosen because kills clustered on 12M/15M/18M seeds |
| **Reserve stance** | **10–15%** — ⭐ **context, not instruction. The user decides** | Pre-registered rule fired its middle row |

---

## 3. ORCL — VALUATION BANDS

Base-case **FY2029 EPS ≈ $11** `[C]`. Path: FY27 ~$8.10 (company guidance) `[V]` · FY28 ~$9.55
`[C]` · FY29 ~$11.00 `[C]` · FY30 ~$12.30 `[C]`.

| Price | P/E on FY29 | Band |
|---|---|---|
| **< $140** | < 12.7× | Extreme bear — exceptional *if the thesis is intact* |
| **$140–160** | 12.7–14.5× | **Bear accumulation** |
| **$160–180** | 14.5–16.4× | Attractive asymmetric |
| **$180–200** | 16.4–18.2× | Reasonable / base |
| **$200–220** | 18.2–20.0× | Fair to full |
| **$220+** | 20.0×+ | Bull priced |

⚠️ **PEG alone is invalid for ORCL.** EPS growth can look excellent while FCF stays deeply
negative. Any valuation read carries FCF conversion, capex intensity, debt and dilution alongside
the multiple.

**Re-derivation:** offered only after an **EPS change** or a **thesis change (C4/C5)** — ⛔ never
because the price moved. ⛔ **Never re-derive downward and then call the lower price attractive.**
If EPS fell, the bands fell; that is the thesis weakening.

---

## 4. ORCL-SPECIFIC THRESHOLDS

| Rule | Value |
|---|---|
| **Head start fires** | `current_price` **≤ $160** **AND** (`avg_cost` **> $160** **OR** `shares` = 0) |
| **Head start blocked** | Price > $160 (any average) **OR** `avg_cost` ≤ $160 |
| **Single-day trigger** | **>10% down** → mandatory cause check |
| **Cumulative trigger** | **~20% below** where the long tracker opened → same check |
| **Multiplier caps** | Long **≤6×** · swing **≤3×** · ⛔ **dip-side only, never on a green day** |

⚠️ **The head start is a *valuation* bet, not a drawdown bet.** The pooled study tested
drawdown-launched swing trackers across 12 names and found no edge — ORCL's own Δ was **−3.59pp
against σ 3.76pp**. ⛔ **Never cite the simulations as support for the head start.** Its only
justification is the price sitting in the bear band.

---

## 5. ORCL — EVENT MAP

| # | Date | Event | Evidence question |
|---|---|---|---|
| **EV1** | **2026-12-14** `[V]` | Q2 FY2027 earnings | Is Q1 strength a trend or a peak? |
| **EV2** | ~1 week after EV1 `[A]` | ⭐ **Q2 10-Q filing** | What does the footnote say the call didn't? |
| **EV3** | ~2027-03-10 `[A]` | Q3 FY2027 | Is capex/revenue turning? |
| **EV4** | ~2027-06-10 `[A]` | Q4 + FY2027 | OpenAI revenue was to start in 2027 `[V]` — did it? |
| **EV5** | ~2027-09-09 `[A]` | Q1 FY2028 | Does the ~$30B/yr ramp `[1S]` begin on time? |

⭐ **EV2 is the highest-value date and the one most people skip.** The call gives headline RPO;
the 10-Q footnote holds customer concentration, RPO duration and the maturity ladder. **The call
is marketing; the filing is testimony.**

⚠️ Only EV1 is confirmed. ⛔ Re-verify EV3–EV5 before any of them releases capital.

**Undated triggers:** U1 OpenAI funding/distress · U2 new debt or equity issuance · U3 credit
rating action · U4 Ellison/insider transactions · U5 layoffs or restructuring charges · U6 named
multicloud DB win or loss · U7 Stargate delay · U8 AI-sector sentiment move.

---

## 6. CAUSE TAXONOMY — ORCL-specific content

⭐ The **codes and their handling** are in the Engine. **What each code looks like for Oracle** is
here.

| Code | For ORCL, recognisable by |
|---|---|
| **C1** | Broad tech selloff; peers down similarly; no ORCL-specific disclosure |
| **C2** | AI-infrastructure rotation; AI-infra names move together; multiple compresses, business doesn't |
| **C3** | A miss on a line that is **not** OCI growth / RPO / capex / FCF |
| **C4** | OCI growth <30% · RPO stalls · capex accelerating faster than revenue · FCF worsening |
| **C5** | OpenAI renegotiates, delays or cannot fund · RPO grows while conversion stalls 2+ quarters · capex still accelerating into FY2028 · forced equity raise at a depressed price · AI-infra ROIC established as inadequate · multicloud DB decelerates or stops being disclosed |

### ⭐ Worked example — classify separately, then net

September 2026: Oracle announced layoffs **and** Ellison cancelled a $7.5B stock sale a day after
setting it up. Shares fell ~5% — layoff **costs** outweighed the cancelled sale `[V]`.

⚠️ The naive read — *"layoffs mean lower opex, therefore good"* — **gets the direction wrong.**
Two events, opposite signs, one session.

### ⛔ Explicitly not signals for ORCL

A 15% fall · OCI decelerating 120% → 80% · one quarter missing guidance · analyst downgrades ·
volatility · a new RPO record · an enormous-sounding AI contract · a bullish Ellison statement ·
another AI partnership.

---

## 7. ORCL — SCORECARD REFERENCE — Q1 FY2027 baseline

⚠️ **These are reference values, not current.** Confirm at session time.

Revenue +30% `[V]` · Cloud +62% `[V]` · **OCI +121%** `[V]` · RPO $664B `[V]` · Capex $28.5B Q1
`[V]`, FY27 guided $90–95B `[1S]` · **FCF ~−$5B Q1** `[V]`, FY26 −$23.7B `[V]` · prepaid +
customer-supplied ~$75B by FY26 end `[V]` · debt ~$125B `[V]` · $20B ATM completed Q1 `[V]` ·
operating margin ~35% GAAP vs ~29% PY `[V]`.

**Load-bearing:** OCI growth (highest priority) · RPO **quality** (read the 10-Q, not the call) ·
capex relative to revenue · **FCF trajectory (ultimate test)**.

---

## 8. ORCL — FUNDING PROFILE — from the pooled large-cap study `[V]`

| Swing length | Peak single-day % of bucket | Range | Cleared within 21 td |
|---|---|---|---|
| **5D** | **24.4%** | 18.0–48.0% | 91.6% |
| 10D | 16.5% | 9.9–32.8% | 92.1% |
| 15D | 12.6% | 7.0–31.1% | 92.1% |
| 20D | 9.9% | 5.3–25.2% | 91.7% |
| 25D | 8.1% | 4.6–20.3% | 88.8% |

**Long tracker:** 10–12% of its capital per 21 trading days, single-day peaks ~3–4%.

⭐ **The bucket is ~90% gone within three trading weeks regardless of length.** Only the
single-day spike changes. ⛔ **Pick by what the user can fund on a single day, never by expected
return** — swing length showed no material return difference in any stratum.

---

## 9. ORCL — THE TWO DOORS — written before entry

**Door A — confirmed.** Capex/revenue falling 2+ consecutive quarters · FCF crossing toward
breakeven · OCI revenue ÷ cumulative OCI capex `[C]` rising · OpenAI revenue converting on
schedule in FY2028 · multicloud DB with named enterprise logos · AI Database broken out as its
own revenue line.

**Door B — broken.** The C5 list in §6, plus: ⭐ **the combination is the danger, not any single
item** — *slowing growth + persistent capex + rising debt + continuing dilution together.* Any one
is survivable. All four is Door B **regardless of what the price has done.**

---

## 10. ORCL — STANDING INTERROGATIONS — never resolve at one event

**I1 — Is OCI differentiated, or AWS/Azure at a discount?** Three falsifiable claims: bare-metal
GPU performance · multicloud workload placement · the 10k+ GPU managed model. ⚠️ **If none is
demonstrably true, the bull case reduces to "big customers won't migrate"** — a decay asset, a
ceiling not a runway.
⭐ **Constructed metric** `[C]`: **OCI revenue ÷ cumulative OCI capex.** FY26 ≈ **0.32** (~$18.1B
÷ ~$55.7B `[V]`). Oracle doesn't publish it. Whether it rises is the cleanest read on whether OCI
is a business or a subsidy.

**I2 — Does Oracle DB matter for greenfield?** A founder wires an LLM to Postgres in an afternoon
and never considers Oracle. If that holds five years, the moat is a **harvest, not a platform.**

**I3 — Does Autonomous / AI Database carry security or trust baggage?** CVE severity · any
breach · whether regulated-sector customers *name* it in production.

**I4 — ⭐ How much of the thesis is OpenAI?** ~$300B over five years from 2027 `[V]`, ~$30B/yr
from FY2028 `[1S]`, against $664B RPO. Ladder position: **signed and take-or-pay** `[1S]` — high
rung, but **not yet funded or in reported revenue.**
⚠️ **Highest-consequence unknown, permanently unresolvable from Oracle's filings** — it depends
on a private company's finances. Lenders have priced it: a data-centre developer pivoted to
Microsoft over Oracle counterparty concentration `[1S]`.

---

## 11. ORCL — ⚠️ WHAT THIS CARD DROPPED

Compressed from the full ORCL analysis. **Go back to `PROMPT_B_orcl_synthesis.md` and
`ORCL_event_map.md` for:** the full business narrative · unit economics and value chain ·
competitive detail (Postgres, Snowflake, Databricks, hyperscalers) · the developer-adoption
thesis · management's transformation record · the full A1–A5 management-action shape · the
bottom-up ceiling · complete wave-1/wave-2 simulation detail.

⭐ **If a session needs any of those, this card is not enough — say so.**

---

## 12. ORCL — HONEST LIMITS CARRIED WITH THIS CARD

1. ⚠️ **"Already down 50%, so downside is limited" does not hold.** ORCL traded at **$114.67 on
   2026-07-28** `[V]` after a 52-week high of **$329.50** `[V]`. A further 25–30% is not a tail
   scenario — it is this stock's own recent completed move.
2. ⚠️ **ORCL is S2, and S2 long trackers in the pooled study clustered at ~−31% — the LARGECAP
   kill threshold** — across every partition seed. ⛔ ORCL itself contributed **zero** rows to
   that finding (insufficient history), so it is a warning about the stratum, not a measurement
   of ORCL.
3. **The conviction gate is untestable.** ⛔ Nothing here says whether the thesis holds.
4. **EV3–EV5 are `[A]`; FY28–FY30 EPS is `[C]`.**
5. ⭐ **Entry timing dominated every configuration parameter measured.** Every dial in this card
   is small next to when the user started.
