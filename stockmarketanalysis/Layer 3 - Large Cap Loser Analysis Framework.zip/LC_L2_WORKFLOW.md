# LARGE-CAP LOSER · LAYER 2 · WORKFLOW

**Seven steps from a Layer 1 artifact to a decision card.**
Each step: goal · what to do · concerns that usually surface · output · when to move on.

⭐ **The rhythm of every step:** do the work → explain anything worrying in plain words → ask once
→ move on when he's ready. Close each step with a two-to-three line summary.

---

## STEP 1 — INTAKE, FACT CHECK, STRATUM

**Goal:** confirm what Layer 1 handed over is correct and complete, and classify the decline.

**Input:** the Layer 1 artifact — fact pack (8–12 quarters), why it fell (temporary vs
structural), competitive position / route back, "what would have to be true" conditions, and
handoff notes.

**Do:**
1. ⛔ **Identity** — verify ticker → CIK. Hard fact, not overridable.
2. **Freshness** — has a newer quarter been reported since Layer 1 was written? If yes, pull it.
3. **Fact-check the load-bearing numbers** — revenue, operating income, operating cash flow,
   capex, cash, debt, share count. Two sources each. Correct anything wrong, and say what changed.
4. **Coverage check** — anything obvious missing? A competitor, a segment, a recent disclosure,
   a regulatory item. List gaps; fill the important ones now.
5. ⭐ **Assign the stratum** — Layer 1 describes the decline but doesn't classify it:

| Stratum | The decline in one line | Example |
|---|---|---|
| **S1 — Multiple compression** | Profitable business, growth scare, the market paid less for the same earnings | NFLX 2022 |
| **S2 — Capital intensity / balance sheet** | Heavy spending, debt, cash flow negative — the market doubts the spending pays off | ORCL 2025–26 |
| **S3 — Secular demand concern** | The market doubts people will want the product the way they used to | NKE, DIS |

Explain the choice in one line from what was disclosed at the time — not from the chart. If it
genuinely sits between two, say so.

⭐ **Why stratum matters (tell him plainly):** it changes what the evidence says about buying on
a big drop. For S1 stocks, jumping in right after a −40% fall did *worse* than buying on a random
day afterward — in 19 of 20 tests. That affects the head start in Step 5.

**Concerns that usually surface:** wrong framework (survival actually in doubt) · stale numbers.

**Output:** corrected fact table · gap list · stratum with one-line reason.

---

## STEP 2 — GROWTH POTENTIAL

**Goal:** make sure every realistic way this business could become meaningfully larger is on the
table — and that each is honestly graded.

**Do:**
1. **List the growth routes** — what the company says, plus what you can see that they don't
   say. For each:

| Route | Rough size | Uses an existing strength? | Similar margins? | Picks a fight with a partner they depend on? | Verdict |
|---|---|---|---|---|---|

2. **Grade honestly.** A route that fails the three checks gets marked "optionality — don't count
   on it," with the reason. ⭐ Killing weak routes is as useful as finding strong ones.
3. ⭐ **The constructed metric** — the one number management doesn't publish but that tells you
   whether growth is real. *(ORCL: OCI revenue ÷ cumulative OCI capex. NFLX: hours per member.)*
   If Layer 1 didn't find one, try to build one now. If none exists, say so.
4. **Link to Layer 1's route back** — do the growth routes and the "route back" agree?

**Concerns that usually surface:** a moat strong for old customers but weak for new ones · growth
that depends on one customer · a big backlog that isn't revenue yet.

**Output:** graded growth table · constructed metric (or "none found") · one line on whether
growth potential supports the thesis.

---

## STEP 3 — CASH FLOW

**Goal:** can the business fund its own plans — and will the shareholder actually capture the
growth? ⭐ For large caps this is usually lighter than for small companies. Keep it proportionate.

**Do:**
1. **Free cash flow** = operating cash flow − capex. Last 8 quarters. Direction matters more than
   level.
2. **Capex ÷ revenue** — rising, flat, or falling?
3. **Debt** — total, direction, and the next big maturity date.
4. ⭐ **Company growth vs per-share growth.** Share count over 8 quarters. If shares grow faster
   than earnings, the company gets bigger while each share gets smaller.
5. **Survival check** — one line. For most large caps: "no credible route to failure on any
   reasonable horizon." ⭐ If the honest answer is anything else, this is a Level 3 concern: the
   stock may belong in the gem framework instead.

**Concerns that usually surface:** negative free cash flow · dilution outpacing growth · debt
rising faster than cash generation.

**Output:** cash flow table · per-share vs company growth · one-line survival verdict.

---

## STEP 4 — BULL / BASE / BEAR RANGES

**Goal:** turn everything so far into price ranges — built from the business outward, never from
a price inward.

**Do:**
1. **Pick an anchor** — usually forward EPS, sometimes free cash flow per share. ⭐ **State the
   basis** — next twelve months, or a named fiscal year. Never unlabelled.
2. **Clean it** — strip one-off items (a termination fee, a legal settlement, an asset sale).
   Show the arithmetic.
3. **Build three scenarios by working backwards:**

| | Bear | Base | Bull |
|---|---|---|---|
| What has to happen in the business | | | |
| Anchor figure (EPS or FCF) | | | |
| Multiple the market would reasonably pay | | | |
| Implied price range | | | |
| ⭐ What early evidence would confirm this path | | | |

⛔ Not "pick a multiple and multiply." Start from what the business must deliver, then ask
whether that's plausible.

4. **Bands** — map price ranges to implied multiples on the base anchor:

| Price | Implied multiple (stated basis) | Band |
|---|---|---|

⭐ Bands tied to multiples move when the anchor moves. Bands tied to prices go stale silently.

5. **Where does today's price sit?** State the band and the multiple being paid. Ask the price
   from the user or check it — and say which.

**Concerns that usually surface:** the price already reflects the bull case · PEG used where
earnings and cash flow disagree · mixed bases.

**Output:** scenario table · band table with basis stated · today's position.

---

## STEP 5 — CONFIGURATION FROM THE POOLED STUDY

**Goal:** set the tracker parameters from `LARGECAP_LOSER_FRAMEWORK_KB.md`. ⛔ No new simulation —
the pooled study covers this class.

**Do:**
1. **Conviction period** — default **2 years**. ⭐ For large caps the limit is *when the evidence
   arrives*, not cash running out. If the key evidence lands later than 2 years, lengthen it and
   say why.
2. **Partition length** — **8–12 months.** Settled; the pooled study confirmed it.
3. **Head-start threshold** — the bear band's upper edge from Step 4.
   - **S1:** ⭐ default **OFF**, or fire only deep in the extreme-bear band. The evidence is
     against drawdown-timed entry for this stratum. Explain it; let him decide.
   - **S2 / S3:** default on, at the bear-band threshold. Still a *valuation* bet — the study
     found no timing edge, so ⛔ never cite it as support.
4. **Multiplier caps** — long **≤6×**. Swing **≤2×** for S1, **≤3×** for S2 / S3. Tag `[A]`.
5. **Swing length** — ⭐ a *funding* choice, not a return choice. The study found no return
   difference across 5–25 days. Pick by what he can afford on a single day (the KB funding table).
6. **Reserve** — his decision. Tell him plainly: the study found no timing edge, so a reserve is
   money not yet deployed, not an opportunity fund. It's a risk dial — more reserve means less
   exposure, not a better outcome.

**Concerns that usually surface:** head start requested on an S1 stock · S2 long trackers in the
study often hit the −30% kill floor.

**Output:** parameter table, each with its source and tag.

---

## STEP 6 — EVENT ROADMAP

**Goal:** a dated schedule of evidence, and the rules for reading news.

**Do:**
1. ⭐ **Convert Layer 1's conditions.** Each "what would have to be true" condition → a dated
   checkpoint with a yes/no question. Each "what would prove it wrong" → a Door B entry and a C5
   example.

| # | Date | The yes/no question | What a NO means |
|---|---|---|---|

⛔ "Q3 earnings" is not a checkpoint. "Does capex growth fall below revenue growth in Q3?" is.
⭐ Put the **quarterly filing (10-Q)** as its own row, separate from the earnings call — customer
concentration and debt schedules live in the filing. Mark unconfirmed dates `[A]`.

2. **Undated triggers** — things that can happen any day (a major customer's trouble, a debt
   raise, an insider sale, a competitor launch).
3. **Cause taxonomy** — what C1–C5 look like *for this stock specifically*:

| Code | Meaning | For this stock, looks like |
|---|---|---|
| C1 | Broad market selloff | |
| C2 | Sector rotation | |
| C3 | A miss on something that doesn't matter to the thesis | |
| C4 | A miss on something that does | |
| C5 | Structural break — a Door B condition | |

Include one worked example where two same-day events pointed in opposite directions.

4. **The two doors** — what would confirm the thesis, what would break it. ⭐ Name the most
   dangerous *combination*, not just single items.

**Output:** event map · triggers · cause taxonomy · two doors.

---

## STEP 7 — DECISION CARD

**Goal:** compress everything into a card Layer 3 can use. Fill `CARD_TEMPLATE_LARGECAP.md`.

**Before finalising, run the checklist:**
- [ ] Retrieval guard is the first thing in the file
- [ ] ⭐ **Ticker in every section heading** — `## 3. {TICKER} — VALUATION BANDS`
- [ ] All twelve standard headings present
- [ ] Explicit multiplier caps
- [ ] Stale-by date
- [ ] Every multiple's basis stated
- [ ] Every section reference points at the right section
- [ ] ⭐ **Every override from this session recorded as a status warning at the top**
- [ ] No position, split, or amount written into the card

**Output:** `CARD_{TICKER}.md`, then three lines on what makes this card different from the
samples.
