# DECISION CARD — NFLX

# ⛔ THIS CARD APPLIES ONLY TO NETFLIX, INC. (NFLX)

**If the question concerns any other ticker, STOP.** Do not read further, do not adapt these numbers, do not reason by analogy from them. Every band, threshold and date below is NFLX-specific and wrong for any other company. Say which ticker you need and stop.

**⛔ If no ticker is specified, STOP and ask.** A generic question ("what should I do today?") must not activate this card.

**Type:** Layer 3 knowledge-base card · **Class:** Large-cap loser, **stratum S1 (multiple compression)**
**Built:** 2026-09-24 · ⛔ **STALE-BY: 2027-02-28**

*Stale-by is deliberately shorter than ORCL's. The January engagement report (EV4) is a thesis-changing event; the bands and the load-bearing metric both need rebuilding after it, not patching.*

---

## 0. NFLX — WHAT THIS CARD IS, AND WHAT IT IS NOT

⭐ **This card is data, not procedure.** It contains no decision tree, no routing, no arithmetic rules, no output format. Those live in the shared Decision Engine, which is the same file for every stock.

**Engine + this card = a complete NFLX session. Neither works alone.**

⛔ **This card cannot be executed on its own.** If the Decision Engine is not loaded, say so and stop rather than improvising a procedure from the contents below.

---

## 1. NFLX — ⭐ ACTIVATION — the card is inert until these are bound

Every value below comes from the DSIP portfolio metadata block the user pastes, or from the user directly. ⛔ **None of them may be assumed, remembered, carried from an earlier session, or sourced from a web search.**

| Slot | Source | If missing |
|---|---|---|
| `current_price` | ⭐ User-confirmed or DSIP block | ⛔ Ask. **Never search for it.** Search snapshots lag intraday by hours |
| `avg_cost` | DSIP block | ⛔ Ask |
| `shares` | DSIP block | ⛔ Ask |
| `deployed` | DSIP block | ⛔ Ask |
| `max_budget` | DSIP block | ⛔ Ask |
| `reserve_remaining` | DSIP block | ⛔ Ask |
| `conviction_period` | DSIP block | Default §2 if absent, and say so |
| `today_recommended_amount` | DSIP block | ⛔ Ask before suggesting any multiplier |
| `partition_no`, `days_elapsed`, `days_expected` | DSIP block | Optional — context only |

⛔ **The three-input gate:** no recommendation of any kind without `avg_cost`, `shares` and `deployed` current as of today. They drift daily.

⚠️ If today's date is after the stale-by date above, **this card is expired.** ⛔ Say so and refuse to reason from it.

**Identity:** Netflix, Inc. · Nasdaq **NFLX** · **CIK 0001065280** · ⛔ Verify by CIK, never by ticker.
**Tier:** **LARGECAP** — target **15%**, kill threshold **−30%**. ⛔ Not PENNY. Every constant differs from the EVGO card.

---

## 2. NFLX — ⛔ HALT GATE — READ BEFORE ANY DEPLOYMENT LOGIC
### The single most important difference between this card and ORCL's

**NFLX is stratum S1. ORCL is S2. On the question that matters most for a card, these two strata behave oppositely.**

> **Pooled large-cap study: 45 of 60 paired differences (drawdown-launch minus random-launch) were negative. In S1 specifically it was 19 of 20.** S1 pooled Δ = **−5.13pp** against σ **4.12pp** — |Δ| exceeds σ, in the negative direction.
>
> ⚠️⚠️ **NFLX's own row: median Δ = −5.92pp, σ = 1.91pp** — one of the tightest, most negative results in the entire study. **And every single swing length was negative:** 5D **−9.01** · 10D **−5.92** · 15D **−4.00** · 20D **−8.08** · 25D **−4.80** `[V]`

⛔ **Therefore: buying NFLX immediately after it clears a drawdown threshold underperformed buying it on a random post-decline day, in every configuration tested.**

⚠️ **This is a stronger statement than ORCL's.** ORCL's card says the simulation found *no edge either way* and the head start is a valuation bet with no simulated support. **For NFLX the simulated evidence is directionally negative.** A head start here is a valuation bet made **in spite of**, not merely without, simulated support.

⛔ **Never cite the simulations as support for a head start on this name.** They argue against it.

---

## 3. NFLX — FROZEN PARAMETERS

| Parameter | Value | Source |
|---|---|---|
| Conviction period | **2 years (504 trading days)** | `[A]` Inherited LARGECAP default. ⛔ No NFLX-specific long-tracker batch was run in this project |
| Partition seed | **8–12 months** | `[V]` Pooled study §4 — S1 spread across seeds is 4.16pp (59.66% / 63.82% / 63.25%), the tightest useful range of any stratum |
| Reserve stance | **10–15%** | ⭐ Context, not instruction. The user decides |
| **Multiplier caps** | ⭐ **Long ≤6× · swing ≤2×** · ⛔ dip-side only, never on a green day | **Long ≤6×: user-set ceiling.** Swing ≤2×: `[A]` — inherited from the more conservative of the two existing cards (EVGO), **not measured on NFLX.** Lower than ORCL's 3× because of §2: on this stratum a drawdown-triggered swing entry measurably underperformed |

⭐ **One genuinely favourable S1 fact, stated honestly:** S1 was the **only stratum with positive pooled long-tracker returns** (+59.66% / +63.82% / +63.25% across 8M/10M/12M seeds) against S2 at ~−31% and S3 at −22% to −33% `[V]`. ⚠️ **But NFLX's own kill count was 12 of 24** — half its long trackers hit the −30% mechanical floor `[V]`. ⛔ The stratum being positive does not make this name safe.

---

## 4. NFLX — VALUATION BANDS

**Anchor: cleaned forward EPS.** ⭐ Netflix has real, durable GAAP earnings, so a P/E anchor is appropriate here — unlike EVGO, which has none.

**Derivation of the anchor, shown:**
- Trailing EPS as reported ≈ **$3.18** `[V]`
- ⚠️ Contains the **$2.8B WBD termination fee** `[V]`, a non-repeating item recognised in Q1 2026 "interest and other income"
- Per share: $2.8B ÷ ~4.25B shares = **~$0.66** `[C]`
- Operations-only trailing ≈ $3.18 − $0.66 = **~$2.52** `[C]`
- ⭐ **Anchor = next-twelve-months (NTM) EPS ≈ $3.51** `[C]` — built as below

**The projection, shown** — every input is this card's own stated figure:

```
Q2 op income        12.56B × 33.4%            = $4.20B
Net/op conversion   3.4B ÷ 4.20B              = 0.810      (Q2, ex-fee)
FY26 op income      $51.2B guide mid × 31.5%  = $16.13B
FY26 net, clean     16.13B × 0.810            = $13.07B
FY26 EPS, clean     13.07B ÷ 4.25B sh         = ≈ $3.08   ← calendar FY26
FY27 EPS, rough     57.1B × 33% × 0.810 ÷ ~3.99B sh (buyback) = ≈ $3.82
NTM ≈ midpoint      (3.08 + 3.82) ÷ 2         = ≈ $3.45   ← reproduces $3.51 within ~2%
Cross-check         Q2 EPS $0.80 × 4          = $3.20 run rate
```

⚠️⚠️ **$3.51 is an NTM figure, not FY26.** An earlier version labelled it "FY26"; clean FY26 is
~$3.08. ⭐ **This matters for the head start:** the "$50 is below the 2022 trough multiple" claim
in §5 holds on an NTM basis (14.2×) and **fails** on a FY26 basis (16.3×). ⛔ **Always compare
multiples on the same basis** — the 2022 trough (~15×) must also be read as NTM for the
comparison to hold. Mixing bases silently moves every band edge by ~14%.

**EPS path** `[C]`: FY26 clean **~$3.08** · **NTM ~$3.51 (band anchor)** · FY27 **~$3.82–4.00**
· FY28 ~$4.56 (base case)

| Price | P/E on NTM ~$3.51 | Band |
|---|---|---|
| **< $50** | < 14.2× | ⭐ **Extreme bear** — below the 2022 trough multiple. Exceptional if the thesis is intact |
| **$50–60** | 14.2–17.1× | **Bear accumulation.** ⚠️ Wells Fargo's $57 target and its 15× multiple sit inside this band |
| **$60–70** | 17.1–19.9× | **Attractive asymmetric.** The 52-week low of $65.08 `[V]` sits here |
| **$70–80** | 19.9–22.8× | **Reasonable / base** — the "ordinary company" multiple |
| **$80–90** | 22.8–25.6× | **Fair to full** |
| **$90+** | 25.6×+ | **Bull priced.** ⚠️ Street consensus (~$94–97 `[V]`) implies this band |

⭐ **Historical multiple context, for calibration only:** ~39–47× forward in the 2021–2025 "special company" era `[C]` · ~19× in mid-2026 `[C]` · ~15× at the 2022 trough `[C]`. **A multiple is a mood. It has no floor.**

⚠️ **PEG is valid here** (unlike EVGO, where there is no E) **but must use the correct G.** Operating income growth ~20% `[V]`, not revenue growth ~12% `[V]`. Using revenue growth turns a PEG of ~0.95 into ~1.6 — a different verdict on the same company.

**Re-derivation:** offered only after an EPS change or a thesis change (C4/C5) — ⛔ **never because the price moved.** ⛔ Never re-derive downward and then call the lower price attractive. If EPS fell, the bands fell; that is the thesis weakening.

---

## 5. NFLX-SPECIFIC THRESHOLDS

| Rule | Value |
|---|---|
| ⚠️⚠️ **Head start fires** | `current_price ≤ $50` **AND** (`avg_cost > $50` **OR** `shares = 0`) |
| **Head start blocked** | Price > $50 (any average) **OR** `avg_cost ≤ $50` |
| Single-day trigger | >10% down → **mandatory cause check** (§7) |
| Cumulative trigger | ~20% below where the long tracker opened → same check |
| **Multiplier caps** | ⭐ **Long ≤6× · swing ≤2×** · ⛔ dip-side only. Swing cap is `[A]`, not measured — see §3. Size within the cap by §9 affordability |

⚠️⚠️ **Why the head-start threshold is set at the extreme-bear band and not the bear-accumulation band:** §2. Every swing length tested on this name was negative. Setting the trigger at $60 or $57 would be dip-buying a name where dip-buying measurably underperformed. **$50 is deep enough that it is a valuation event rather than a drawdown reaction** — roughly a further 30% below the September 2026 level and below the 2022 trough multiple **on an NTM basis** (14.2× vs ~15×). ⚠️ On calendar FY26 EPS the same $50 is 16.3× — *above* the trough. The claim holds only when both multiples use the same basis (§4).

⭐ **The honest default for this card is head-start OFF.** ⛔ If the user wants one anyway, state §2's finding once, plainly, and let them choose.

---

## 6. NFLX — EVENT MAP

| # | Date | Event | Evidence question |
|---|---|---|---|
| **EV1** | ~2026-10 `[A]` | **Q3 2026 earnings** | ⭐ Does operating margin print **≥33.2%**? Management's own guided number `[V]` — pass/fail, in the one metric they cannot hide |
| **EV2** | ~1 week after EV1 `[A]` | ⭐ **Q3 10-Q filing** | What does the footnote say the call didn't? Ad revenue detail, regional mix, content amortisation schedule |
| **EV3** | 2026 Q3–Q4 `[A]` | **Advertiser upfront commitments** | Management said these close "in the coming weeks" as of July `[V]`. Did they, and at what CPMs? |
| **EV4** | ~2027-01 `[A]` | ⭐⭐⭐ **Q4 + FY2026 results, the ANNUAL engagement report, and 2027 guidance** | **Does hours per member stabilise?** Does the 2027 guide hold double-digit revenue growth? |
| **EV5** | ~2027-04 `[A]` | **Q1 2027** | First print of the **15-new-market ad expansion** year `[V]`. Is ad revenue compounding or plateauing? |

⭐⭐ **EV4 is the highest-value date on this card and both sides of the argument now agree on it.** The bull case rests on engagement stabilising; Wells Fargo explicitly named the January viewership report as its negative catalyst `[V]`. ⚠️ **From 2027 the engagement report moves from twice a year to once a year** `[V]` — so after EV4 the next equivalent datapoint is roughly **twelve months away**, not six. Checkpoint spacing must account for that.

⚠️ Only EV3's existence is management-confirmed. ⛔ **Re-verify EV1 and EV4–EV5 dates before any of them releases capital.**

**Undated triggers:** U1 a **third** disclosure reduction · U2 Paramount–WBD integration or competitive action · U3 a major sports-rights bid (bends the content cost curve) · U4 a price increase announcement · U5 any ad-tier ARM or ad-revenue disclosure change · U6 buyback pace change from the ~$4.7B/quarter run rate · U7 insider transactions **outside** the programmatic pattern (see §7) · U8 a content slate hit or flop of unusual scale.

---

## 7. CAUSE TAXONOMY — NFLX-specific content

⭐ The codes and their handling are in the Engine. What each code looks like **for Netflix** is here.

| Code | For NFLX, recognisable by |
|---|---|
| **C1** | Broad market or tech selloff; peers down similarly; no NFLX-specific disclosure |
| **C2** | ⭐ **Multiple compression without business change** — a downgrade, a multiple cut, sector de-rating. The business is unchanged that day |
| **C3** | A miss on a line that is **not** engagement / ad revenue / operating margin / member growth — FX, a one-time charge, a tax item |
| **C4** | ⚠️ **Thesis weakening:** hours per member declining **faster** · ad revenue tracking below ~$3B FY26 · operating margin below the guided figure · member growth below ~6% · ad CPMs compressing further |
| **C5** | ⚠️⚠️ **Structural break:** engagement decline **continuing into the ad era** while ad growth stalls · a **third** disclosure cut · ad-tier ARM gap not closing across multiple quarters · a price increase producing measurable churn · Paramount–WBD demonstrably taking share · content spend reaccelerating (sports rights) while margin guidance falls |

### ⭐ Worked example — classify separately, then net

**18 September 2026:** Wells Fargo downgraded NFLX to Underweight from Equal Weight, cut its price target to $57 from $80, and **lowered its valuation multiple to 15× forward earnings from 21×** `[V]`. It was the **first Underweight rating on the stock** — prior coverage was 35 buy and 16 hold, with no sells `[V]`. Shares fell ~4% `[V]`.

⚠️ **The naive read — "a bank turned bearish, therefore the thesis broke" — gets the classification wrong.** Decompose:

- **The rating action itself is C2.** The multiple went 21× → 15×. Netflix's business did not change on 18 September. This is sentiment repricing.
- **The evidence cited is a C4 watch item.** Top 100 Originals hours per subscriber per day fell 3% YoY in H1 2026; US TV share per Nielsen dropped below 8%; viewing at 1.6 hours per subscriber per day in H1, down 8% from 2023 after adjusting for the password-sharing crackdown and geographic mix `[V]`. **That is the load-bearing metric, and it is the analyst's data, not Netflix's disclosure.**
- ⭐ **Net: a C2 event citing C4 evidence that will only be resolved at EV4.** The correct response is to note the evidence and wait for the January print — **not** to treat a downgrade as either a thesis break or a buying opportunity.

⚠️ **Volume on the drop was ~27.7M shares against a ~42.6M daily average `[V]` — roughly 35% lighter.** That is thin conviction on both sides, not distribution.

### ⭐ The insider-transaction filter for this name

NFLX insider sales run on a **recurring, identical-size pattern**: 27,312 shares in February 2026, 27,312 in May 2026, tied to RSU/PSU vesting and Rule 144 `[V]`. ⛔ **Identical share counts on a schedule are the signature of a 10b5-1 plan, not a discretionary view.** U7 fires only on transactions **outside** this pattern.

### ⛔ Explicitly NOT signals for NFLX

A 20–30% fall · a single analyst downgrade or upgrade · the consensus price target · one quarter of slower revenue growth · volatility · a record content-spend announcement · a large-sounding sports or live-event deal · a bullish management statement about engagement without published data.

---

## 8. NFLX — SCORECARD REFERENCE — Q2 2026 baseline

⚠️ **These are reference values, not current. Confirm at session time.**

Revenue **$12.56B, +13.4%** `[V]` · EPS **$0.80** `[V]` — a beat · Operating margin **33.4%** `[V]`, above guidance · Net income ~**$3.4B** `[V]` · FY26 revenue guide narrowed to **$51.0–51.4B** from $50.7–51.7B `[V]` ⚠️ *top of the range chopped* · Q3 guide **~11.7–12% growth, 33.2% margin** `[V]` · Growth staircase **16.2% → 13.4% → ~11.7%** `[V]` · H1 viewing **97B hours, +2%** `[V]` against members **+~5%** `[C]` · Content spend **~$18B → ~$20B, +10%** `[V]` vs revenue +13% · Buyback **$4.7B in Q2**, largest ever, **~$27B remaining** ≈ 9–10% of shares `[C]` · SBC **~1% of revenue** `[V]` — genuine shrinkage, not a treadmill · FY25 margin **29.5%** vs FY24 **26.7%**, FY26 target **31.5%** `[V]`.

⚠️ **One-timers cut both ways:** Q3 2025's 28.2% margin `[V]` contained a one-time **~$600M Brazilian tax charge** `[V]`; cleaned, the base was ~31.5% `[C]`. **The apparent +5pt YoY expansion at EV1 is closer to +1.7pt clean** `[C]`.

**Load-bearing, in order:**
1. ⭐⭐⭐ **Hours per member** — highest priority (§11, I1)
2. **Ad revenue** against the ~$3B FY26 target `[V]` ⚠️ *and against the ~$3.3B consensus* `[V]` — it can hit guidance and still "miss"
3. **Operating margin** against the guided figure — the one number they cannot retract
4. **Member growth** — ~7.8% in 2025 `[V]`, post-harvest run rate

---

## 9. NFLX — FUNDING PROFILE — from the pooled large-cap study `[V]`

⚠️ **Pooled across all 12 names, not S1-specific and not NFLX-specific.** ⛔ Do not present it as measured on this stock.

| Swing length | Peak single-day % of bucket | Range | Cleared within 21 td |
|---|---|---|---|
| 5D | 24.4% | 18.0–48.0% | 91.6% |
| 10D | 16.5% | 9.9–32.8% | 92.1% |
| 15D | 12.6% | 7.0–31.1% | 92.1% |
| 20D | 9.9% | 5.3–25.2% | 91.7% |
| 25D | 8.1% | 4.6–20.3% | 88.8% |

**Long tracker:** 10–12% of its capital per 21 trading days, single-day peaks ~3–4%.

⭐ **The bucket is ~90% gone within three trading weeks regardless of length.** Only the single-day spike changes. ⛔ **Pick by what the user can fund on a single day, never by expected return** — swing length showed no material return difference in any stratum (S1 best-to-worst spread 4.4pp, well inside the 4–16pp within-length IQR) `[V]`.

⚠️ **And read §2 first.** The funding table tells you how to size a swing tracker. It does not tell you to open one — on this name, the study argues against doing so on a drawdown trigger.

---

## 10. NFLX — THE TWO DOORS — written before entry

**Door A — confirmed.** Hours per member **stabilises or turns positive** at EV4 · ad revenue meets or beats ~$3B FY26 with CPMs holding in the premium tier · operating margin prints ≥ the guided figure at EV1 · 2027 guidance holds **double-digit** revenue growth · the 15-market ad expansion lands on schedule `[V]` · ad-tier ARM gap visibly narrowing (disclosed or triangulable) · buyback pace sustained.

**Door B — broken.** The C5 list in §7, plus: ⭐ **the combination is the danger, not any single item** — engagement still leaking **and** ad revenue missing **and** margin guidance cut **and** a further disclosure reduction, together. **Any one is survivable. All four is Door B regardless of what the price has done.**

⛔ **Never exit on price alone.** Price is the crowd's opinion; the doors are tied to evidence.

⚠️ **The thesis-complete door matters unusually much on this name.** A large share of any return here comes from **multiple re-rating**, and multiple-driven returns are reversible — confirmed seven times in the gem library. If NFLX re-rates toward the upper bands **before** EV4 resolves engagement, the holder is being paid for a future that has not yet been proven.

---

## 11. NFLX — STANDING INTERROGATIONS — never resolve at one event

**I1 — ⭐⭐⭐ Is the attention leak deferred or destroyed?**
⭐ **Constructed metric `[C]`: hours per member = total viewing hours ÷ members.** Netflix publishes the numerator and the denominator in **separate places** and never divides them. H1 2026: viewing +2% against members ~+5% → **≈ −3% per member** `[C]`.
⚠️ **In the ad model this stops being an engagement signal and becomes revenue** — ad income scales with hours watched, while subscription income does not. The metric was a smoke detector; it is now a cash register.
**The open question:** is this content-slate cyclicality (deferred) or permanent share loss to free alternatives — YouTube above all (destroyed)? ⛔ **Unresolvable from any single quarter.** Watch the Q5-style checkpoint: does member growth or churn follow the engagement decline within 4–6 quarters?

**I2 — Can ad ARM close the gap to subscription ARM?**
Triangulated `[C]`: ~$3B/yr ÷ 12 ÷ ~110M ad memberships ≈ **~$2.30/member/month**, against Standard-with-ads at $8.99 `[V]` → **~$11.30 total vs Premium's $26.99** `[V]`. ⚠️ A premium-to-ads downgrade destroys ~$15/month and brands currently replace about a seventh of it. Management calls closing the gap "an opportunity" `[V]`. **Cable historically earned roughly half its revenue from advertising** — the bet is that the brand dollar eventually outgrows the discount. ⛔ Not there yet.

**I3 — Is the member engine maturing or saturated?**
325M members against management's ~800M addressable households `[V]` — already 40%+ penetrated, in 190+ countries with China and Russia excluded `[V]`. ⚠️ **Absurdity test:** 8% growth for five years demands ~477M = ~60% of every addressable household on Earth `[C]`. ⛔ Not a base case. Sober underwriting: **4–6% fading toward 2–4%** `[C]`. **Therefore growth must come from monetisation, not members.**

**I4 — What did losing Warner Bros. actually cost?**
Netflix signed at $82.7B on 5 Dec 2025, was outbid by Paramount Skydance's all-cash $31/share, declined to raise, and received the $2.8B termination fee `[V]`. ⚠️ **The financial loss was zero — the strategic question is open.** Paramount now owns the arsenal Netflix wanted. ⭐ **Note also what management's own choice revealed:** they concluded the next act had to be *bought* for $83B rather than built internally, then returned the war chest via buybacks.

**I5 — Is the disclosure reduction maturity or concealment?**
Two cuts in fifteen months, each landing on the metric under maximum scrutiny: subscriber counts stopped from Q1'25; the engagement report halves from 2027 `[V]`. ⭐ **Uncheckable claims get a discount, not the benefit of the doubt** — part of why this trades at an ordinary multiple rather than a premium one. ⚠️ A **third** cut is a C5 trigger.

---

## 12. NFLX — ⚠️ WHAT THIS CARD DROPPED

Compressed from the full NFLX analysis. Go back to the source sessions for: the complete business narrative and unit economics · the full ad-engine sizing (CPM ladder, the funnel/attribution argument, the 41-hour crossover) · the regional ARM map · the full WBD timeline · the trump-card inventory (ad-load dial, regional price escalator, FAST/free tier, gaming, bundling, dividend initiation, slow-motion privatisation) · the three-scenario EPS model and its full arithmetic · the four-engine decomposition · the six-book lens · the live-events strategy and its technical history · the management A1–A5 action shape.

⭐ **If a session needs any of those, this card is not enough — say so.**

---

## 13. NFLX — HONEST LIMITS CARRIED WITH THIS CARD

⚠️⚠️ **"Already down 40%, so downside is limited" does not hold.** 52-week range: **$65.08 low, $124.86 high** `[V]`. ⭐ **The 2022 precedent is this stock's own history: a ~75% peak-to-trough decline** `[V]`. A further 25–30% is not a tail scenario for NFLX — it is a completed move this company has made before.

⚠️⚠️ **§2 is the binding constraint on this card.** NFLX is S1, where the drawdown trigger is **actively harmful**, and NFLX's own row is among the most negative in the study with the tightest dispersion. ⛔ This is the one finding that must never be softened into ORCL's "no edge either way."

⚠️ **NFLX's long-tracker kill count was 12 of 24** `[V]` — half hit the −30% mechanical floor. ⛔ That is the floor being reached, **not** evidence about Netflix. Say *"deployment halted, evaluate the thesis."*

⚠️ **A large share of any return here is multiple re-rating, which is borrowed, not durable.** The gem library confirmed reversibility seven times.

⚠️ **The pooled study is survivorship-biased** — all 12 names still trade; large caps that were acquired, delisted or restructured are absent `[V]`. Every figure is optimistic by an unmeasured amount.

⚠️ **Identity in the pooled study was NOT CIK-verified** `[V]`. ⛔ Verify NFLX's CIK independently.

⚠️ **The pooled study's price bars did not match external feeds** `[V]`. ⛔ Absolute price levels from that study must not be read against any other source — including the bands in §4, which were built from filings, not from the engine.

⚠️ **Every price and per-share figure on this card is post–10:1 split.** §2's NFLX row — the card's
binding constraint — came from pooled-study windows anchored in the **2022** drawdown, which
should not straddle the split date. ⛔ **Confirm that once** against the pooled study's anchor
report; a window straddling an unadjusted split would read as a fake ~90% drop and invalidate
that row.

**EV1 and EV4–EV5 dates are `[A]`. FY27–FY28 EPS is `[C]`.** The NTM anchor of $3.51 is `[C]`,
not a company figure — see §4 for its arithmetic and the NTM-vs-FY26 distinction.

**The conviction gate is untestable.** ⛔ Nothing here says whether the thesis holds.

⭐ **Entry timing dominated every configuration parameter measured** — median ratio 4.0×, and every one of the 12 names above 1 `[V]`. **Every dial in this card is small next to when the user started.**

---

*Educational analysis, not financial advice — do your own research or consult a registered advisor for anything you act on.*
