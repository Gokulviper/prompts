# LARGE-CAP LOSER FRAMEWORK — KNOWLEDGE BASE

**Layer 2 framework file. Replaces per-stock simulation waves for this class.**

Built 2026-09-18 from `LARGECAP_LOSER_SYNTHESIS.md` (1,197 rows, 12 names, 0 failures)
⛔ **Applies to mega-cap losers only.** A gem-tier small cap has different tier constants
(24%/21% target, −50% kill) and different volatility structure. ⛔ **Do not apply this file to
that class.**

Tags: `[V]` verified from raw data · `[C]` computed · `[A]` assumption · `[1S]` single source

---

## 0. ⭐ THE FOUR FINDINGS, STATED FIRST

**1. The drawdown trigger does not help, and for one stratum it actively hurts.**
Pooled Δ (drawdown-launch minus random-launch) = **−3.02pp against σ 4.86pp** → no pooled edge.
But **45 of 60 paired differences are negative**, and in S1 it is **19 of 20** `[C]`. S1's
Δ = **−5.13pp against σ 4.12pp** — |Δ| exceeds σ, in the negative direction.

> ⭐ **Buying a multiple-compression mega-cap immediately after it clears −40% underperformed
> buying it on a random post-decline day.** 3 of 4 S1 names, same direction.

**2. Swing length does not matter.** In every stratum the spread between the best and worst
length's median (4.4pp S1 · 6.3pp S2 · 1.7pp S3) sits well inside the within-length dispersion
(4–16pp IQR). ⭐ **Pick a length you can fund and attend to. It is not an alpha decision.**

**3. ⚠️ DSIP tracks naive equal-daily deployment almost exactly in a swing window.**
|DSIP − naive| is under **1.3pp everywhere**, and in S1 DSIP *trails* naive by a widening
margin as length grows (−0.38pp at 5D → −1.01pp at 25D). ⭐ **In a 5–25 day window the engine's
dip-weighting adds no measurable return over simply splitting the money evenly.** Its value here
is mechanical discipline, not alpha. ⛔ Never claim otherwise.

**4. Timing beats configuration in all 12 names.** Median ratio **4.0×**, range 2.3× (NKE) to
15.0× (ADBE), **every name above 1** `[C]`. Smaller than the ORCL long-tracker precedent (~18×)
because a 5–25 day window gives length less room to compound before the tracker closes.

---

## 1. ⛔ THE STRATUM SYSTEM — classify before anything else

**"Large-cap loser" is not one population.** Assign from **what was disclosed at the time of the
decline, never from the price chart.**

| Stratum | Cause | Names tested |
|---|---|---|
| **S1 — Multiple compression** | Profitable business, growth scare, multiple de-rates | NFLX, META, ADBE, CRM |
| **S2 — Capital intensity / balance sheet** | Heavy spend, debt, FCF negative, returns on capital questioned | ORCL, INTC, BA, WBD |
| **S3 — Secular / demand concern** | The market doubts end demand or the moat | NKE, DIS, EL, LULU |

⚠️ **If a name is genuinely ambiguous, say so rather than forcing a pick.** PYPL was excluded
from the study for exactly this reason — it sits between S1 and S3.

### ⭐ Why the stratum is the single most decision-relevant fact

| Stratum | Δ (drawdown vs random) | σ | Operating consequence |
|---|---|---|---|
| **S1** | **−5.13pp** | 4.12pp | ⛔ **Drawdown launch is actively worse** |
| **S2** | −2.47pp | 3.38pp | No edge — trigger is neutral |
| **S3** | −0.18pp | 4.95pp | ⚠️ No edge — **but this conceals a split** |

⚠️ **S3's "no edge" describes nothing.** NKE shows **+4.26pp** (the only name in the study with
a positive edge) and DIS shows **−3.34pp**. They cancel. ⭐ **Read the per-name row, never the
S3 pooled figure.**

### Per-name detail — check whether one name drove a stratum

| Symbol | Str | median Δ | σ | Verdict |
|---|---|---|---|---|
| NFLX | S1 | −5.92pp | 1.91 | ⛔ actively worse |
| META | S1 | −12.17pp | 4.43 | ⛔ actively worse |
| ADBE | S1 | −0.89pp | 1.26 | no edge |
| CRM | S1 | −5.46pp | 2.46 | ⛔ actively worse |
| ORCL | S2 | −3.59pp | 3.76 | no edge |
| INTC | S2 | −5.59pp | 2.61 | ⛔ actively worse |
| BA | S2 | +0.31pp | 2.24 | no edge |
| WBD | S2 | −1.88pp | 2.12 | no edge |
| NKE | S3 | **+4.26pp** | 3.54 | ⭐ **edge — the only one** |
| DIS | S3 | −3.34pp | 1.53 | ⛔ actively worse |
| EL | S3 | −2.15pp | 3.41 | no edge |
| LULU | S3 | +0.70pp | 6.80 | no edge |

---

## 2. ⭐ SWING LENGTH — a funding decision, not a return decision

Pick by what a user can actually fund on a single day. **These are the numbers the affordability
conversation runs on.**

| Length | Peak single-day % of bucket (median) | Single-day range | Cleared within 21 td |
|---|---|---|---|
| **5D** | **24.4%** | **18.0–48.0%** | 91.6% |
| **10D** | 16.5% | 9.9–32.8% | 92.1% |
| **15D** | 12.6% | 7.0–31.1% | 92.1% |
| **20D** | 9.9% | 5.3–25.2% | 91.7% |
| **25D** | 8.1% | 4.6–20.3% | 88.8% |

⭐ **The bucket is ~90% gone within three trading weeks no matter which length is chosen.** Only
the single-day spike changes. A 5D tranche can demand **nearly half the bucket in one day.**

⭐ **The practical rule:** shorter length = higher single-day demand, identical three-week total,
no return difference. **Choose by wallet, not by conviction.**

---

## 3. ⚠️ WHAT THE NUMBERS ACTUALLY WERE — do not soften this

Arm D median net profit, by stratum and length, over 5–25 trading day windows:

| | 5D | 10D | 15D | 20D | 25D |
|---|---|---|---|---|---|
| **S1** | −0.48% | −2.72% | −2.91% | −4.94% | −2.53% |
| **S2** | +1.52% | −2.14% | −1.84% | −4.74% | −2.53% |
| **S3** | −1.31% | −0.17% | +0.39% | −0.23% | −0.94% |

⚠️ **Most cells are negative.** Opening a swing tracker on a mega-cap immediately after it
cleared −40% produced a **negative median short-window return in this pool**, across all three
strata, at most lengths. The naive baseline was negative too — DSIP didn't cause it — but ⛔
**nothing here supports a claim that this trigger is a good moment to deploy.**

⚠️ **And the dispersion dwarfs the medians.** IQRs run 4–16pp against medians of ±5%. Individual
rows range from **−55.3% to +75.6%**. ⭐ **Any single instance tells you almost nothing.**

---

## 4. LONG TRACKERS ON THIS CLASS

**Partition seed 8–12 months holds.** Confirmed, not re-derived.

| Stratum | 8M | 10M | 12M | Spread |
|---|---|---|---|---|
| S1 | 59.66% | 63.82% | 63.25% | 4.16pp |
| **S2** | **−31.57%** | **−31.75%** | **−31.66%** | **0.18pp** |
| S3 | −22.34% | −32.61% | −27.27% | 10.27pp |

⚠️⚠️ **S2 is the row to understand.** All three seeds cluster within 0.18pp, all at roughly
**−31%** — which is the **LARGECAP kill threshold of −30%**. ⭐ **Most S2 long trackers in this
pool hit the kill switch regardless of configuration.** Kill counts: WBD 24/24, META 21/24,
INTC 14/24, NFLX 12/24, EL 15/24, LULU 12/15, BA 8/24, NKE 2/6.

⛔ **This is not evidence about those companies.** It is the mechanical −30% floor being reached.
Say *"deployment halted, evaluate the thesis."*

⚠️ **ORCL contributed zero arm-P rows** — its 2025-12 episode has only ~191–290 trading days of
coverage, never reaching the 504 days arm P requires. ⛔ **Every S2 long-tracker figure above
excludes ORCL.**

---

## 5. ⛔ SWING TRACKERS CANNOT SUCCEED — structurally

`PartitionLifecyclePolicy` gates both SUCCESS and graceful-close on `!isSwingTrade`. **Zero
SUCCESS end reasons across all 960 arm-D/R rows** `[V]`.

| Stratum | NEUTRAL_ZOMBIE | NEUTRAL_PARTITION | KILL | STILL_ACTIVE |
|---|---|---|---|---|
| S1 | 148 | 154 | 2 | 16 |
| S2 | 163 | 124 | 5 | 28 |
| S3 | 166 | 128 | 0 | 26 |

⭐ **Read a swing tracker's outcome as a mark-to-market at the horizon you chose, never as "did
the thesis play out."** 70 of 960 rows (7.3%) never closed at all within their window.

---

## 6. ⭐ HOW TO USE THIS FOR A NEW LARGE-CAP LOSER

**This replaces running a simulation wave.**

1. **Classify the stratum** from disclosures at the time of decline. Ambiguous → say so.
2. ⭐ **Check whether the drawdown trigger even helps.**
   - **S1** → ⛔ **it is actively worse.** Do not build a drawdown-triggered entry into an S1
     card. If the user wants one anyway, state the finding once and let them choose
   - **S2 / S3** → neutral. The trigger neither helps nor hurts; it is a *magnitude* marker, not
     an authorisation
3. **Pick swing length by funding fit** using §2's table. ⛔ Not by expected return.
4. **Long tracker: seed 8–12 months.** ⚠️ In S2, expect the kill switch to dominate regardless.
5. ⛔ **Never expect SUCCESS from a swing tracker.**
6. **Set entry expectations honestly** from §3 — most short-window medians here were negative.

### ⭐ What still has to be built per stock

The pooled study settles **configuration**. It settles nothing about the company. Every
large-cap card still needs, built by hand:

- The **thesis sentence** and the two competing equations
- **Valuation bands** tied to an EPS or equivalent base, with implied multiples
- The **event map** — dated evidence, each with pre-written pass/fail
- The **cause taxonomy** C1–C5, stock-specific
- The **two doors** — what would confirm, what would break
- A **stale-by date**

⭐ **The simulation was never going to tell you any of that.**

---

## 7. ⚠️ HONEST LIMITS — reproduce these wherever the findings are cited

1. ⚠️⚠️ **Survivorship.** All 12 names still trade. Large caps that fell and were acquired,
   delisted or restructured are absent. ⭐ **The pool is biased toward recovery and every figure
   is optimistic by an unmeasured amount.**
2. **12 correlated paths, not 12 samples.** BA and WBD both decline 2020-03; NFLX, META and CRM
   all cluster in 2022. They share macro factors.
3. **No true zeros are testable.** Downside is a floor, not a bottom.
4. ⚠️⚠️ **Identity was NOT CIK-verified** — the engine has no CIK field. Symbols were matched by
   regex against `stocks.stock_name`. ⛔ The ticker-continuity trap (three instances in the gem
   library; SPWR resolved to two different companies) is **not guarded against here.**
5. ⚠️⚠️ **The engine's price bars do not match external feeds.** On ORCL, 443 of 982 days
   differed from an independent close by up to **$16.29**, on an identical trading calendar.
   Anchors and simulation share the same series so the study is internally consistent, but ⛔
   **absolute price levels from this study must not be read against any other source.**
6. **Capital was $100,000 per row** (engine-hardcoded), not the CSV's cosmetic "100." Relevant
   to any dollar comparison across studies.
7. **Day-1 lock-in is 20% of a 5D tranche's life** and cannot be averaged out — the seed is
   deterministic on date and price move. ⭐ **Every 5D figure is a point estimate.**
8. **`is_fractional_shares_allowed` is inert** engine-wide. Results do not transfer to a build
   where rounding binds — and rounding bites hardest at small buckets, which is what a swing
   bucket is.
9. **Stratum assignment is judgment.** The one-line justifications exist so disagreement is
   checkable.
10. **Snapshot-bound to 2026-09-18.**

---

## 8. ⭐ WHAT THIS CHANGES IN THE EXISTING ORCL ARTIFACTS

ORCL is **S2**. Its own Δ was **−3.59pp against σ 3.76pp — no edge**, consistent with its
stratum. Three consequences:

- ⭐ **The head-start tracker survives, but its justification is narrower than it looks.** It is
  a **valuation** bet — price sitting in the bear band — not a drawdown bet. The study tested
  drawdown launches and found nothing. ⛔ Never cite the simulations as support for the head
  start.
- ⭐ **The §2 funding table replaces the ORCL-specific numbers** in Prompt B/C and is better —
  it is per-length rather than one blended figure.
- ⚠️ **If a future card is S1, the head-start mechanism should be off by default.** 19 of 20 S1
  pairs pointed against the trigger.

---

*Educational analysis, not financial advice — do your own research or consult a registered
advisor for anything you act on.*
