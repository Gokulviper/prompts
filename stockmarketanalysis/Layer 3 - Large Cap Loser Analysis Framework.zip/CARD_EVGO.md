# ⛔ THIS CARD APPLIES ONLY TO EVGO INC. (EVGO)

**If the question concerns any other ticker, STOP.** Do not read further, do not adapt these
numbers, do not reason by analogy from them. Every band, threshold, tier constant and date below
is EVGO-specific and **wrong for any other company** — the tier is PENNY, the kill floor is −50%,
and there are no earnings, so nothing here transfers to a large-cap card. Say which ticker you
need and stop.

**Type:** Layer 3 knowledge-base card · **Class:** Gem-path candidate, PENNY tier
**Built:** 2026-09-19 · ⛔ **STALE-BY: 2026-12-31**

> ## ⚠️⚠️ STATUS: GATE 0 FAILED — AUTHOR-OVERRIDDEN, NOT A CLEARED CANDIDATE
>
> Gate 0 (does an entry stage open now) **failed 2026-09-08**: operating-leverage inflection
> pushed to 2028–29, GAAP net profitability 2031 at earliest. Gates 1–3 (survival,
> deferred-vs-destroyed, capture) passed 2026-09-06. Both records stand — they test different
> things.
>
> ⭐ **The author has knowingly overridden Gate 0 on a stated safety-net thesis (§6) and holds a
> live position.** This card exists to record that decision and its falsification conditions,
> **not to represent a passed gate.** Any session reading this card must carry the override
> forward explicitly and must not treat EVGO as gate-cleared.

---

## 0. EVGO — WHAT THIS CARD IS, AND WHAT IT IS NOT

⭐ **This card is data, not procedure.** It contains no decision tree, no routing, no arithmetic
rules, no output format. Those live in the shared Decision Engine, which is the same file for
every stock.

**Engine + this card = a complete EVGO session. Neither works alone.**

⛔ If the Decision Engine is not loaded, say so and stop rather than improvising a procedure from
the contents below.

---

## 1. EVGO — ⭐ ACTIVATION — the card is inert until these are bound

Every value below comes from the DSIP portfolio metadata block the user pastes, or from the user
directly. ⛔ None may be assumed, remembered, carried from an earlier session, or sourced from a
web search.

| Slot | Source | If missing |
|---|---|---|
| `current_price` | ⭐ **User-confirmed** or DSIP block | ⛔ **Ask. Never search.** At ~$1.40 a two-cent lag is 1.4% of the whole price |
| `avg_cost` | DSIP block | ⛔ Ask |
| `shares` | DSIP block | ⛔ Ask |
| `deployed` | DSIP block | ⛔ Ask — and see the booking warning in §12 |
| `max_budget` | DSIP block | ⛔ Ask |
| `reserve_remaining` | DSIP block | ⛔ Ask |
| `conviction_period` | DSIP block | Default §2 if absent, and say so |
| `today_recommended_amount` | DSIP block | ⛔ Ask before suggesting any multiplier |
| `partition_no`, `days_elapsed`, `days_expected` | DSIP block | Optional — context only |

⛔ **The three-input gate:** no recommendation of any kind without `avg_cost`, `shares` and
`deployed` current as of today.

⚠️ **Position of record at build time**, for continuity only — ⛔ **not a substitute for a fresh
bind:** 395.5545 shares, blended ~$1.56 `[1-SOURCE — user-stated 2026-09-19]`. ⚠️ A prior session
recorded ~$1.58; the discrepancy is unresolved. Cost basis at $1.56 ≈ **$617.07** `[CONSTRUCTED]`.

⚠️ If today's date is after the stale-by date, this card is expired. ⛔ Say so and refuse to
reason from it. A pre-profitability company with a quarterly funding picture goes stale fast.

---

## 2. EVGO — FROZEN PARAMETERS

⭐ **Unlike the ORCL card, these are simulation-supported.** A real EVGO batch ran on 2026-09-08:
**414 cases, 414/414 succeeded, 696 partitions, 0 missing `EndReason`.** Tier pinned PENNY and
asserted before *and* after; every case's last CSV row date equalled its `end_date`.

| Parameter | Value | Support |
|---|---|---|
| Tier | **PENNY** — target 24%, **kill −50%**, per partition | `[VERIFIED]` engine constant |
| ⭐ Effective SUCCESS threshold | **+19.2%, not 24%** | `[VERIFIED]` — `PartitionLifecyclePolicy` ORs three conditions where `netProfitProgress >= 0.8` dominates and `partitionProgress` is a literal alias of it, so 24% is **unreachable** |
| Partition seed | ⚠️ **Not answerable as "converged"** | 15M/18M partitions never close at any anchor; A4/A5/A6 close none at any length. Reported as pacing sensitivity, not convergence |
| Conviction period | ⚠️ **Undocumented** — 3Y/756d inherited from wave1 | ⛔ **No H1–H4 derivation exists for EVGO.** Ran anyway, by explicit prior decision. Treat as `[ASSUMPTION]` |
| Style effect | GRADUAL −25.33% · MODERATE −25.58% · AGGRESSIVE −26.00% (mean) | `[VERIFIED]` — all three aggregation methods agree on ordering |
| Reserve stance | ⭐ **Context, not instruction. The user decides** | Breakeven invariant across `w` |

⭐ **The single most useful parameter finding: entry timing dominates style by roughly 25:1.**
Style spread ≤1.2 points on any aggregation method; anchor spread ≥30 points. Every dial in this
card is small next to when the user started.

⚠️ **No Arm-A anchor ran a full 3Y.** Trading days actually simulated: A1 251, A2 206, A3 166,
A4 126, A5 83, A6 43 — against a 756-day horizon. **A4/A5/A6 simulate under a sixth of what the
duration implies**, which is why later anchors look better. That is window length, not entry
quality.

---

## 3. EVGO — VALUATION BANDS

⛔ **EVGO has no earnings and will not for years** — GAAP net profitability 2031 at earliest. A
P/E band is impossible. **The anchor is EV ÷ annualised charging-network revenue, with EV ÷ stall
as the countable cross-check.**

**Components** `[VERIFIED]` Q2 2026 (reported 2026-08-05):

```
shares         141,715,720 Class A + 172,800,000 Class B = 314,515,720   (10-Q cover, 2026-07-28)
net debt       $297M total debt − $198M cash & restricted = $99M
charging rev   $61M in Q2 × 4 = $244M annualised                          [CONSTRUCTED]
stalls         5,380 in operation (+24% YoY)
EV             = shares × price + $99M                                    [CONSTRUCTED]
```

| Price | EV | EV ÷ charging rev | EV ÷ stall | Band |
|---|---|---|---|---|
| $0.78 | $344M | 1.41× | **$64,000** | Kill floor on a $1.56 basis — see §4 |
| $1.00 | $414M | 1.69× | $76,862 | Author's safety-net level (§6) |
| **$1.22** | **$484M** | **1.98×** | **≈$90,000** | ⭐ **Network valued at exactly its own build cost** |
| $1.40 | $539M | 2.21× | $100,246 | **Current** |
| $1.56 | $590M | 2.42× | $109,599 | Author's blended cost |
| $2.00 | $728M | 2.98× | $135,322 | |
| $3.00 | $1,043M | 4.27× | $193,782 | |
| $5.18 | $1,728M | 7.08× | $321,225 | 52-week high |

⭐ **The $1.22 line is the one that means something in business terms.** The company's own Q2
unit-economics disclosure puts **net capex at ~$90,000 per stall** `[1-SOURCE]`. Below ~$1.22,
the market is paying **less than it costs EVgo to build the network it already owns.** That is
recomputable from two disclosed numbers and it moves when either moves — which is what a band
anchor has to do.

⚠️ **Why charging revenue and not total revenue:** non-charging (eXtend) was roughly half of Q1
2026 revenue at different margins. **Headline growth overstates the core business.** The line to
watch is charging-network revenue — $61M in Q2, +19% YoY, 18th consecutive quarter of
double-digit growth `[VERIFIED]`.

⛔ **Re-derivation** happens only after a change in charging revenue, stall count, or net debt —
⛔ **never because the price moved.** ⛔ Never re-derive downward and then call the lower price
attractive.

---

## 4. EVGO-SPECIFIC THRESHOLDS

| Rule | Value |
|---|---|
| **Head start fires** | `current_price ≤ $1.22` **AND** (`avg_cost > $1.22` **OR** `shares = 0`) |
| **Head start blocked** | Price > $1.22 (any average) **OR** `avg_cost ≤ $1.22` |
| **At build time** | ⛔ **BLOCKED** — $1.40 > $1.22 |
| Single-day trigger | >12% down → mandatory cause check (§6 taxonomy) |
| Cumulative trigger | ~20% below where the long tracker opened → same check |
| Multiplier caps | Long ≤6× · ⭐ **swing ≤2×, not ORCL's 3×** · ⛔ dip-side only, never on a green day |
| **Kill floor, current basis** | −50% of $1.56 = **$0.78** `[CONSTRUCTED]` |

⚠️⚠️ **The head start is a VALUATION bet, not a drawdown bet.** ⛔ **Never cite the simulation as
support for it.** The EVGO batch tested this directly and it did not support it — see §8. Its
only justification is the price sitting below replacement cost.

⭐ **Why the swing multiplier cap is lower than ORCL's.** From EVGO's own simulation §8: a swing
tracker's worst single day demands up to **26.6% of its entire bucket**, against the long
tracker's **0.76%**. That is a **35× difference in single-day funding demand** on this stock. On
a PENNY-tier name with a dated solvency gate, the honest default is **smaller than ORCL's, or off
entirely.**

---

## 5. EVGO — EVENT MAP

| # | Date | Event | Evidence question |
|---|---|---|---|
| **EV1** | **2026-11-09** `[VERIFIED]` | Q3 2026 results | ⭐ **Is daily throughput per stall rising year over year?** Q3 2025 is the number to beat |
| EV2 | ~1 week after EV1 `[A]` | Q3 10-Q | What does the footnote say the call didn't — DOE draw, customer concentration, covenant headroom |
| EV3 | ~2027-03 `[A]` | Q4 + FY2026 | Did FY2026 land inside the $400–430M guide? Is recurring adj. EBITDA (ex one-offs) positive? |
| EV4 | ~2027-08 `[A]` | Q2 2027 | ⭐ Did the promised **2.5–3× step-up in 2027 stall additions** actually arrive? |
| EV5 | **2030-03** | ⭐⭐ **DOE principal amortisation begins** | Can it be serviced from operations? |

⚠️⚠️ **The 2030-03 gate is materially smaller than every prior session recorded.** The widely
carried **~$104M/yr figure is STALE** — computed on the original $1.248bn facility. After the
April 2026 reduction to **$750M**, a fully-drawn facility amortises at roughly **$62–64M/yr**,
and **only $226.1M is drawn today** `[PRIOR — re-verify]`. ⭐ It still lands **before** the
earliest GAAP-profitability estimate of 2031. That tension is the Gate 2 problem and it has not
gone away — it is simply smaller than recorded.

⚠️ **Only EV1 is confirmed.** ⛔ Re-verify EV2–EV4 before any of them releases capital.

**Undated triggers:** U1 DOE draw halted or covenant tripped · U2 equity issuance at a depressed
price · U3 ⭐ **Nasdaq minimum-bid deficiency notice** (see §6) · U4 LS Power board or ownership
action · U5 a major site host converting to self-supply at scale · U6 Tesla or Uber agreement
scope change · U7 short-interest unwind or squeeze · U8 EV-sector policy or subsidy change.

---

## 6. EVGO — ⭐⭐ THE SAFETY-NET THESIS — the author's Gate 0 override, recorded with its falsification

**The author's stated reasoning, verbatim in substance:** *if EVGO trades below $1, there is a
decent chance it bounces back above $1 — competitors such as Blink have gone below $1 and
recovered multiple times. That floor makes the position survivable even if the business thesis
disappoints, because the position can be averaged and exited on the bounce.*

⭐ **This card records that thesis as the author's. It does not endorse it.** What follows is the
evidence on both sides, because a decision card that carried only the thesis would be an
advertisement.

### 6.1 The thesis in its strongest form

- ⭐ **Short interest is 41.4M shares — 31.0% of float, up 43% since September 2025, with 10.4
  days to cover** `[1-SOURCE, 2026-09-11]`. On a $440M company that is a real mechanical
  bounce mechanism, and it is the **strongest single argument** for the thesis.
- **EVgo is in materially better financial shape than Blink.** Net debt $99M against ~$835M
  available liquidity including >$630M undrawn DOE and bank capacity `[VERIFIED]`. Blink carries
  an accumulated deficit of ~$834M with ~$38M cash `[1-SOURCE]`.
- The business is growing: 18 consecutive quarters of double-digit charging-revenue growth,
  39% TTM charging gross margin, +2pp YoY `[VERIFIED]`.

### 6.2 ⚠️⚠️ The precedent does not survive verification

**Blink Charging (BLNK) has not bounced back. It is still below $1 a year later.**

| Date | What actually happened | Tag |
|---|---|---|
| Dec 2025 | Priced a public offering: **26,666,666 shares at $0.75** — ~$20M gross | `[1-SOURCE]` |
| **2026-01-26** | Nasdaq deficiency notice — closed below $1.00 for 30 consecutive business days, Rule 5550(a)(2) | `[VERIFIED]` |
| **2026-07-27** | First 180-day cure period expired — **compliance not regained** | `[VERIFIED]` |
| **2026-07-28** | Nasdaq granted a **second** 180-day window to 2027-01-25 — after Blink **indicated it may use a reverse stock split** | `[VERIFIED]` |
| Recent | Trading ~**$0.68** | `[1-SOURCE]` |

⭐ **The thesis conflates two different claims, and only one of them is supported:**

- **(a) "EVGO is unlikely to reach $1."** Genuinely supported — by liquidity, by growth, by the
  gap between EVgo's balance sheet and Blink's.
- **(b) "If EVGO reaches $1, it bounces back."** ⛔ **This is the claim the cited precedent
  contradicts.** Blink went under, stayed under for a year, failed its cure period, and the
  remedy on the table is a reverse split — not a recovery.

### 6.3 ⚠️⚠️ The safety-net scenario walks into two of the framework's own kill triggers

The project's disqualification screen lists as KILL: **reverse split in the prior 12 months** ·
**second compliance breach below $1**.

⭐ **So the event being treated as the safety net is the same event the framework treats as a
disqualifier.** If EVGO goes below $1 for 30 business days, the sequence is: deficiency notice →
180-day cure → possible second 180 days → reverse split as the standard remedy. That is Blink's
actual path, and each step is a screen hit.

⚠️ **And the dilution mechanism runs the wrong way.** EVgo has an ATM and an effective shelf.
A company raising equity below $1 is issuing the most shares at the worst price — which is
precisely what Blink did at $0.75. **There is no floor beneath an unlimited share count.**

### 6.4 What would settle it, in advance

**Falsification conditions for the safety net, written before the event:**
- ⛔ A Nasdaq minimum-bid deficiency notice is filed → the thesis enters its test, not its payoff
- ⛔ A reverse split is announced or indicated to Nasdaq → **the thesis has failed**; the "bounce"
  becomes an artefact of share-count arithmetic, not a recovery
- ⛔ An equity raise prices below $1.00 → dilution has overtaken the floor
- ⛔ A first 180-day cure period lapses without compliance → Blink's path, confirmed

⭐ **And the honest framing the Engine must apply:** *averaging down because the price fell is
not the safety net operating — it is averaging down.* The framework retired "already down 90%, so
downside is limited" precisely because there is no floor beneath an unlimited share count. If a
session finds itself reasoning from the chart toward more capital, **say so directly.**

---

## 7. CAUSE TAXONOMY — EVGO-specific content

⭐ The codes and their handling are in the Engine. What each looks like for a charging network is
here.

| Code | For EVGO, recognisable by |
|---|---|
| **C1** | Broad small-cap or high-beta selloff; EV names down similarly; no EVGO disclosure |
| **C2** | EV-sector rotation — charging peers (BLNK, CHPT) move together; multiple compresses, business doesn't |
| **C3** | A miss on a line that is **not** throughput per stall, charging revenue, stall adds, or liquidity |
| **C4** | ⭐ Throughput per stall falling YoY again · charging revenue growth dropping below double digits (breaking an 18-quarter streak) · stall adds slipping · charging gross margin compressing |
| **C5** | DOE draws halted or covenants tripped · **throughput per stall falling for consecutive quarters** · a major site host converting to self-supply at scale · an equity raise at a materially depressed price · the 2030 amortisation becoming unservicable from operations · a Nasdaq deficiency notice |

⛔ **Explicitly NOT signals for EVGO:** a 20% fall · one quarter of softer sequential throughput ·
analyst price-target cuts (Roth $3→$2, Stifel $7→$6, both Aug 2026) · volatility · a new
partnership announcement · a stall-count record · the **warrant** delisting (see §12) · high short
interest on its own.

---

## 8. FUNDING PROFILE — from EVGO's own simulation `[VERIFIED]`

⭐ **This replaces the large-cap pooled table entirely.** That study covered mega-caps only and
explicitly excluded gem-tier names.

**Peak single-day deployment, as a fraction of the normalised 100 budget** (n=414 cases):

| Tracker type | Mean peak single day | Median | Max |
|---|---|---|---|
| **BASELINE (long tracker)** | **0.45** | 0.44 | **0.76** |
| EVENT_PROXY (155D/439D/514D) | 11.81 | 10.13 | 25.53 |
| PLACEBO_PROXY | 11.68 | 10.05 | 25.64 |
| DRAWDOWN (swing) | 14.95 | 13.59 | 24.06 |
| DRAWDOWN_PLACEBO | 18.13 | 19.76 | 26.62 |

⭐ **The long tracker deploys under 1% of budget on its worst single day.** Dip-sizing spreads
capital thinly across a 250+ day window. **A swing bucket demands up to 26.6% in one day** — 35×
more. ⛔ **Pick swing length by what can be funded on a single day, never by expected return.**

**Capital actually deployed by window end, long tracker, by anchor** (of 100):

| Anchor | Mean deployed | Range | Final cumulative NetProfit% |
|---|---|---|---|
| A1 (2025-09-08) | 49.78 | 35.85–65.58 | **−41.74%** (−44.35 to −39.53) |
| A2 (2025-11-08) | 42.71 | 29.83–57.01 | −35.13% |
| A3 (2026-01-08) | 35.33 | 24.38–48.20 | −30.71% |
| A4 (2026-03-08) | 32.81 | 20.58–41.15 | −20.51% |
| A5 (2026-05-08) | 26.44 | 15.12–35.89 | −17.50% |
| A6 (2026-07-08) | 11.35 | 7.82–14.66 | **−8.24%** |

⭐⭐ **That 33-point spread across six 2025–26 calendar start dates IS the finding.** Later anchors
look better only because they simulate a much shorter, more recent slice of a stock still
falling — **not because they represent a better entry.** The correct response to dispersion this
wide is a **more conservative configuration**, not picking the anchor that looked best.

**A long tranche structurally consumes ~two-thirds of its allocation:** 155D 67.53 · 439D 65.31 ·
514D 64.12 (of 100). The residual ~31–36% never gets deployed inside the window at all, and
deployment style barely moves it.

⛔ **Every mechanical trigger tested was null or inconclusive.** Short swing cells lost to placebo
in 20 of 36. Long cells were extreme and anchor-dependent with **opposite signs on the same event
at different anchors** (E3-439D-A1 −32.75 to −39.99; E1-155D-A2 +32.68). Arm D had **exactly one
historical trigger day in five years** (−25.95%, 2024-12-17) — n=1 is not a distribution.
Consistent with the library's pooled p≈0.64.

---

## 9. EVGO — ⭐⭐ THE KILL-SWITCH FINDING — read this before using §8

**Zero kill-switch partitions across all 696.** But the synthesis's reading of that — *"the kill
switch had essentially no opportunity to fire"* — ⚠️ **is not what the raw partition data shows,
and this card corrects it.**

**The worst partition-level drawdown ever recorded was −49.83%.** The PENNY kill floor is
**−50.00%**.

| | |
|---|---|
| Case | `EVGO-A1-P15M-GRD` partition 1 (identically GRD/MOD/AGG) |
| Minimum partition-level net profit | **−49.83%** |
| Date it occurred | ⭐ **2026-09-02** — two trading days before the snapshot close |
| Margin to the kill floor | ⭐⭐ **0.17 percentage points** |
| Further price decline required to fire | ⭐ **0.34%** `[CONSTRUCTED]` |
| Outcome recorded | `OPEN_AT_WINDOW_END` — the window simply ran out first |

**How close the rest came:** 6 of 696 partitions reached −48% or worse · 42 reached −45% · 63
reached −40% · 108 reached −30% · **0 crossed −50%.**

⭐⭐ **This is the framework's own retired finding, reproduced live on this stock.** The library
retired kill-switch state as evidence about a company because two names finished **0.36pp apart**
in kill-trigger and went +1,087% and −99.49%. **EVGO's margin was 0.17pp — less than half that —
and it landed on the second-to-last trading day of the window.**

⛔ **Therefore: the zero-kill result is a coincidence of where the window ended, not a property of
the stock, and absolutely not a protective feature of the engine.** Any session citing "the kill
switch never fired on EVGO" as reassurance is making exactly the error the framework retired.

⚠️ The structural reason no partition crossed: **each new partition re-bases its cost against the
current, already-depressed price** rather than inheriting the prior partition's loss. Dip-buying
resets the kill clock every rollover — which is why several trackers finished with
tracker-*cumulative* losses beyond −40% while no single partition ever hit its own floor.

---

## 10. EVGO — SCORECARD REFERENCE — Q2 2026 baseline

⚠️ Reference values, not current. Confirm at session time.

**Load-bearing, in priority order:**

1. ⭐⭐ **Daily throughput per stall — the one number that settles this name.**
   **276 kWh in Q2 2026 vs 281 in Q2 2025 = −1.8% YoY** `[VERIFIED]`. Q1 was 257 vs 266 = −3.4%.
   ⭐ **The decline narrowed. It did not reverse.** Management called it *softer than originally
   expected as we entered 2026*. The +7% sequential move is seasonal — the same step happened in
   2025.
2. **Charging-network revenue** — $61M, +19% YoY, 18th consecutive double-digit quarter
3. **Stall adds** — 5,380 total (+24% YoY); 280 added in Q2, 175 legacy units decommissioned;
   ⚠️ **~60% of the full-year build is weighted to Q4**, so Q3 will look thin by construction
4. **Liquidity** — $198M cash & restricted, $297M total debt, $99M net debt, ~$835M available

**Other Q2 2026:** network throughput 99 GWh (+13% YoY, +9% sequential) · TTM energy 384 GWh
(+16%) · charging gross margin 39% TTM (+2pp) · utilisation ~20% · revenue per stall ~$62,578/yr
at 36% charging-network gross margin → ~$22,589 gross profit, less ~$11,652 sustaining G&A =
**~$10,937 annual cash flow per stall** `[1-SOURCE]` · 1.8M customer accounts (+99k) · 240 NACS
stalls across ~100 sites · Q2 EPS −$0.15 vs −$0.10 · **Tesla agreement signed** for EVgo-branded
V4 Superchargers · FY2026 guidance maintained at $400–430M revenue and −$25M to −$5M adj. EBITDA.

⚠️ **Management's 2030 scenario** — 425–475 kWh/day at 22–25% utilisation, $99,900–115,100 revenue
per stall, $41,200–52,700 cash flow per stall, 1.7–2.2 year paybacks, ~$0.5bn recurring adjusted
EBITDA — is a **CLAIM**, not a fact. ⭐ **It requires throughput per stall to rise ~54–72% from
276. The metric is currently falling.** Target and trend point in opposite directions.

---

## 11. EVGO — THE TWO DOORS — written before further capital moves

**Door A — confirmed.** Daily throughput per stall rising **year over year** for two consecutive
quarters · charging revenue growth holding double digits · charging gross margin expanding ·
the 2.5–3× 2027 stall step-up arriving on schedule · recurring adjusted EBITDA (ex one-offs)
turning positive · DOE draws proceeding without covenant strain.

**Door B — broken.** The C5 list in §7, plus: ⭐ **the combination is the danger, not any single
item** — throughput per stall falling + charging growth decelerating + an equity raise at a
depressed price + DOE draws slowing, together. Any one is survivable. All four is Door B
**regardless of what the price has done.**

⚠️ **Door B is not "the price fell."** ⛔ Never exit on price alone. And ⛔ a kill-switch firing is
**not** Door B — say *"deployment halted, re-evaluate the thesis."*

---

## 12. EVGO — STANDING INTERROGATIONS — never resolve at one event

**I1 — ⭐ Can this business be cost-cut to profitability?** Prior work concluded **no**:
depreciation and interest compound with every stall built, and three of five cost lines were
growing faster than revenue `[PRIOR — re-verify]`. If that holds, cost programmes are theatre and
only throughput per stall matters.

**I2 — ⭐ The constructed metric: throughput per stall.** Stalls +24% while network throughput
+13% — so **throughput per stall must fall**, and it did. EVgo is adding capacity faster than it
fills it. ⭐ **One public number, unambiguous, and it carries the thesis.** Whether it inflects is
the cleanest read on whether the network is a business or a subsidy.

**I3 — The LS Power clock.** LS Power holds four board seats including the Compensation Committee
chair `[PRIOR — re-verify]`. ⭐ **A PE sponsor's fund life is a constraint on the company's
timeline that no filing states.** Class B shares (172.8M) exceed Class A (141.7M) — ⚠️ **minority
holders have limited protection if the sponsor becomes counterparty rather than ally.**

**I4 — ⭐ What is the Tesla agreement actually worth, and on which rung?** Signed, for
EVgo-branded V4 Superchargers with placement in Tesla's navigation `[VERIFIED]`. ⚠️ **Signed is
not funded and not in reported revenue.** No disclosed value, no disclosed stall commitment, no
disclosed termination terms. ⛔ Until it appears in charging-network revenue it is a rung, not a
number.

**I5 — Who captures the margin?** Ionna (eight OEMs, 30,000-stall target by 2030) and the
self-supplying site-host trend (Circle K, Walmart) both attack from above and below `[PRIOR]`.
⚠️ JD Power 2026 satisfaction: EVgo 601 vs industry 666 `[PRIOR — re-verify]`.

---

## 13. EVGO — ⚠️ WHAT THIS CARD DROPPED

Compressed from a much larger body of work. Go back to `EVGO_SYNTHESIS.md` (2026-09-08), the
event-map session (2026-09-08), the gate/configuration session (2026-09-06) and
`synthesis_data.json` for: the full business narrative and two-minute drill · the eight business
phases · the complete board and management ledger and psychology work · the full A1–A5
management-action shape · the bottom-up ceiling and absurdity test · the complete
contracted-vs-hoped-for ladder including Uber · the full 414-case simulation detail and all 696
partition rows · the C1–C8 configuration and its funding check.

⭐ **If a session needs any of those, this card is not enough — say so.**

---

## 14. EVGO — HONEST LIMITS CARRIED WITH THIS CARD

1. ⛔ **Gate 0 is failed and author-overridden.** This card is not a cleared candidate.
2. ⚠️⚠️ **The safety net rests on a precedent that verification contradicts** (§6.2). It is
   recorded as the author's thesis with falsification conditions attached — not as a finding.
3. ⚠️⚠️ **The zero-kill result is a 0.17pp coincidence of window timing** (§9), not a property of
   the stock. ⛔ Never cite it as reassurance.
4. ⚠️ **The conviction period is undocumented** — 756 days inherited from wave1 with no H1–H4
   derivation. Every horizon-relative judgement inherits that.
5. ⚠️ **Simulation runs are not reproducible.** Day-1 lock-in used unseeded `ThreadLocalRandom`
   on that build; the archived raw CSVs are the only record.
6. ⚠️ **Direction was partly known before the batch ran.** EVGO fell ~90% over five years;
   anything deploying capital lower looks good in hindsight. ⭐ **A backtest confirming that DSIP
   is a drawdown instrument is not evidence about the future.**
7. ⚠️ **BX/CX never tested the real events.** E1/E2/E3 are all in the future — earliest ~2027-03.
   They tested gap *lengths* at historical anchors.
8. ⚠️ **No true zeros are testable.** Downside throughout is a floor at the snapshot price, not a
   bottom. Every figure is optimistic by an unmeasured amount.
9. 🚨 **Booking defeats the budget stop.** $1,850 deployed against a $1,000 plan, verified
   elsewhere in this system. ⛔ If prior bookings exist, the app's "total deployed" may understate
   lifetime deployment — reconcile from the lots.
10. ⚠️ **The ~$104M/yr DOE amortisation figure is stale** and appears uncorrected in earlier
    artifacts (§5). Roughly $62–64M/yr fully drawn; $226.1M drawn today `[PRIOR — re-verify]`.
11. ⚠️ **A `Form 25-NSE` sits in EVGO's filing history (2026-07-01).** ⛔ **It is the redeemable
    warrants (EVGOW, $11.50 strike, expired 2026-06-28), not the common stock.** Class A remains
    on the Nasdaq Global Select Market. ⭐ Recorded because "Removal from listing" in a filing list
    otherwise reads as a disqualification hit.
12. ⚠️ **Several `[PRIOR]` figures remain unverified and some are load-bearing:** the $25.9M
    non-recurring closeout behind the Q4 2025 breakeven, the ~64% revenue-per-stall requirement,
    LS Power's four seats, the Ionna 30,000 target, the JD Power scores, the three-of-five
    cost-line finding.
13. ⭐ **Entry timing dominated every configuration parameter measured** (25:1 over style). Every
    dial in this card is small next to when the user started.

---

*Conditional analysis, not a recommendation — do your own research or consult a registered
advisor for anything you act on.*
