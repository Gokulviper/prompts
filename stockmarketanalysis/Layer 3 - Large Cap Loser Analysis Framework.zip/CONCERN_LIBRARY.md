# CONCERN LIBRARY — large-cap losers

**How to explain a worry so a beginner genuinely understands it — then let him decide.**

Every entry: **level** · what it is · an everyday example · the real number · what to ask · what
to record on the card if he proceeds.

⭐ **Rules for using this file**
- Match your words to the level. Don't dress a Level 1 up as a Level 3.
- ⭐ **The analogy explains; the number proves.** Always tie the example back to the real figure.
  An analogy without the number is a story, not an argument.
- ⛔ Never use an analogy that makes the risk sound smaller or bigger than the number shows.
- Explain once. If he's heard it and answered, don't repeat it unless the evidence changed.
- Adapt the example to the business — a bakery for a food company, a toll road for
  infrastructure. The lemonade stand is a default, not a rule.

---

# ⛔ LEVEL 3 — make the case against

Argue it properly: *"This doesn't look good, and here's why… Unless you have something I'm
missing, I don't think it's a good idea to go further."* If he still proceeds, respect it and
record it as a **status warning at the top of the card.**

---

## 3.1 — It isn't really a large-cap loser: survival is in doubt

**What it is:** the large-cap framework assumes the company will survive and asks whether it
recovers. If survival itself is uncertain, you're using the wrong checklist.

**Example:** a car-service checklist asks whether the tyres need replacing. It never asks whether
the car is on fire. If it's on fire, a perfect tyre report is worthless.

**Tie back to:** Step 3's survival check — cash, debt maturities, free cash flow. If the honest
answer isn't "no credible route to failure," say so.

**Ask:** *"I think this belongs in the gem framework, which checks survival first. Do you want to
switch, or continue here knowing this framework won't test survival?"*

**If he proceeds, record:** ⚠️ *Survival not tested — analysed under the large-cap framework by
user choice despite a live survival question.*

---

## 3.2 — The thesis can't be tested inside the conviction period

**What it is:** if none of the evidence that would prove the thesis right or wrong arrives before
the conviction period ends, you'll hold for the full period and learn nothing.

**Example:** buying a ticket for a race that finishes after your ticket expires. You'll never
find out whether you picked the winner.

**Tie back to:** Step 6's event map. If every decisive checkpoint falls after the conviction
end date, this concern is live.

**Ask:** *"Should we lengthen the conviction period so it covers the evidence — or accept holding
through a period where nothing gets confirmed?"*

**If he proceeds, record:** ⚠️ *Decisive evidence arrives after the conviction period ends.*

---

## 3.3 — The company grows but each share shrinks

**What it is:** a company can raise money by issuing new shares. If it issues shares faster than
it grows, the business gets bigger while your piece of it gets smaller.

**Example:** a bakery bakes a bigger pizza — but cuts it into many more slices. The pizza grew.
Your slice shrank.

**Tie back to:** Step 3's per-share vs company growth. Compare share-count growth against
earnings growth over 8 quarters, with the arithmetic shown.

**Ask:** *"Even if the growth story is right, dilution could eat most of it for you. Are you
comfortable with that, or should we look for signs the issuing stops first?"*

**If he proceeds, record:** ⚠️ *Share count growing faster than earnings — per-share value at
risk even if the thesis succeeds.*

---

## 3.4 — Wanting a head start on an S1 stock

**What it is:** for multiple-compression stocks, the data says buying right after a big drop did
worse than buying at a random later time.

**Example:** a shop marks everything 40% off. Instinct says buy on day one. But across 20
comparisons in this category of stock, buying the moment the fall crossed −40% did *worse* than
buying on a random later day in **19 of them**.

⭐ Be honest about the limits: *we measured that it happened; we don't fully know why.* Don't
invent a reason.

**Tie back to:** `LARGECAP_LOSER_FRAMEWORK_KB.md` — S1: 19 of 20 paired comparisons negative,
Δ −5.13pp against σ 4.12pp. For NFLX specifically: every swing length tested was negative.

**Ask:** *"A head start here would be a pure valuation bet made against what the data showed.
Still want it — maybe only if the price gets much deeper?"*

**If he proceeds, record:** ⚠️ *Head start enabled on an S1 stock despite measured negative
evidence for drawdown-timed entry.*

---

# LEVEL 2 — explain, then ask once

Explain plainly, tie to the number, ask if he's comfortable. **If yes, proceed** and add a
one-line note to the card.

---

## 2.1 — Selling more, but cash keeps shrinking

**Example:** your lemonade stand sells more cups every month — sales up 30%. But to sell them you
keep buying bigger fridges, and borrowing to pay for them. At year end you've sold record
lemonade and have *less cash than you started with*.

**The question:** not whether people want the lemonade, but whether the fridges ever pay for
themselves.

**Real case — ORCL:** revenue up ~30% while FY2026 free cash flow was about **−$23.7B**.

**Ask:** *"Do you see a believable point where spending slows and cash turns positive?"*

---

## 2.2 — One customer carries too much of the story

**Example:** most of your lemonade orders come from one big office. As long as they keep
ordering, business is great. If they cut back, most of your sales disappear at once.

**Real case — ORCL:** the OpenAI agreement (~$300B over five years) against total contracted
backlog of ~$664B. A large share rests on one company's ability to pay.

**Ask:** *"How comfortable are you depending this heavily on one customer staying healthy?"*

---

## 2.3 — A big backlog isn't money yet

**Example:** pre-orders for a new bike aren't sales. The customer can cancel, the factory can be
late, and the money only arrives when the bike is delivered and paid for.

**Real case — ORCL:** ~$664B of contracted future obligations. Real and important — but its
timing, profitability and conversion into cash are all still open questions.

**Ask:** *"Are you counting the backlog as future revenue, or waiting to see it convert?"*

---

## 2.4 — Strong with old customers, weak with new ones

**Example:** the only grocery in an old neighbourhood — everyone shops there because switching is
hard. But in every new neighbourhood, a dozen shops compete and people pick freely.

**Real case — ORCL:** very hard to move off for existing mission-critical systems. For new
projects, many developers default to free alternatives.

**Ask:** *"Does the thesis need new customers, or just keeping the old ones?"*

---

## 2.5 — The price already assumes the good outcome

**Example:** paying for championship tickets before the season starts. If they win, you paid a
fair price. If they don't, you overpaid for a hope.

**Tie back to:** Step 4. If today's price sits in the bull band, the market is already paying for
the best case.

**Ask:** *"What's left to gain if the bull case is already priced in?"*

---

## 2.6 — Debt growing faster than the cash to pay it

**Example:** borrowing to expand your shop is fine if new sales repay the loan. If the loan grows
faster than the sales, you're moving further from being able to repay it.

**Real case — ORCL:** total debt around **$125B** and rising, while free cash flow is negative.

**Ask:** *"Do you see the point where cash generation catches up with the borrowing?"*

---

## 2.7 — Management adding claims ahead of shareholders

**Example:** a bakery owner borrows from a bank. If the bakery struggles, the bank gets paid
before the owner's partners see anything. Every loan puts someone ahead of you in line.

**Tie back to:** the management-actions ledger. Debt raises and preferred shares add claims ahead
of common shareholders.

**Ask:** *"How much of the recent financing puts others ahead of you?"*

---

# RETIRED REASONING — correct gently, at Level 2

These sound sensible and have been tested wrong. Correct once, kindly, with the evidence.

---

## R1 — "It's already down so much, it can't fall much further"

**Why it's wrong:** there's no floor built into a share price. A company can keep issuing shares
and a falling price can keep falling.

**Example:** a ball that has dropped fifty floors can drop another ten. Having fallen far doesn't
mean it's near the ground.

**Real case — ORCL:** it fell from **$329.50** to **$114.67** *after* already being down heavily.

---

## R2 — "They're buying back shares, so management must believe in it"

**Why it's wrong:** a buyback is the company spending company money. It isn't executives risking
their own. It's a different signal entirely. Check personal insider purchases (Form 4s)
separately.

**Example:** a manager using the shop's cash to buy stock isn't the same as the manager buying
stock with his own savings.

---

## R3 — "It hit the kill switch, so the company is failing"

**Why it's wrong:** the kill switch is a rule about the *deployment schedule*, not a verdict on
the business.

**Real case:** two stocks sat **0.36 percentage points** apart on the kill measure. One went
**+1,087%**, the other **−99.49%**. The measure couldn't tell them apart.

**Say instead:** *"Deployment halted — time to re-check the thesis."*

---

# LEVEL 1 — note in one line, then carry on

| Situation | One-line note |
|---|---|
| Analyst downgrade | "That's an opinion, not new evidence." |
| A miss on a line that doesn't drive the thesis | "Doesn't touch what matters here." |
| A volatile week | "Price moved; the business didn't." |
| A bullish executive statement | "Words, not evidence — wait for the numbers." |
| A new partnership announcement | "Check what rung it's on — announced isn't signed, signed isn't paid." |

---

## ⭐ THE TEST OF A GOOD EXPLANATION

After you explain, a beginner should be able to say the concern back in one sentence of their own
words. If he couldn't, the explanation failed — try a different example. ⛔ Don't just repeat the
same one louder.
