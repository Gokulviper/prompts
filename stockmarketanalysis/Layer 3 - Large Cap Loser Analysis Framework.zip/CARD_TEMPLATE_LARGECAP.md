# DECISION CARD — {TICKER}

> # ⛔ THIS CARD APPLIES ONLY TO {COMPANY NAME} ({TICKER})
>
> **If the question concerns any other ticker, STOP. Do not read further, do not adapt these
> numbers, do not reason by analogy from them.** Every band, threshold and date below is
> {TICKER}-specific and wrong for any other company.

**Type:** Layer 3 knowledge-base card · **Class:** Large-cap loser · **Stratum:** {S1 | S2 | S3}
**Tier:** LARGECAP (target 15%, kill −30%) · **CIK:** {verified CIK}
**Built:** {date} · ⛔ **STALE-BY: {date}** — {one line: which event forces a rebuild}

---

## ⚠️ {TICKER} — STATUS WARNINGS

⭐ **Every concern the user overrode during Layer 2 goes here, verbatim, one per line.** Layer 3
must state these in every session. ⛔ Delete this section only if there were genuinely no
overrides — then write "None."

- ⚠️ {Override, e.g. "Head start enabled on an S1 stock despite measured negative evidence."}

---

## 0. {TICKER} — WHAT THIS CARD IS, AND WHAT IT IS NOT

⭐ **This card is data, not procedure.** No decision tree, no routing, no arithmetic rules — those
live in the shared engine. ⛔ Cannot be executed on its own.

---

## 1. {TICKER} — ACTIVATION — the card is inert until these are bound

| Slot | Source | If missing |
|---|---|---|
| `current_price` | ⭐ DSIP export or user — ⛔ never search | Ask |
| `avg_cost` | DSIP export | Ask |
| `shares` | DSIP export | Ask |
| `deployed` | DSIP export | Ask |
| `max_budget` | DSIP export | Ask |
| `reserve_remaining` | DSIP export | Ask |
| `today_recommended` | DSIP export | ⛔ Ask before any multiplier |

⛔ **Three-input gate:** no recommendation without `avg_cost`, `shares`, `deployed`, current today.
⚠️ **Past the stale-by date, this card is expired** — refuse to reason from it.

---

## 2. {TICKER} — FROZEN PARAMETERS

| Parameter | Value | Source & tag |
|---|---|---|
| **Conviction period** | {2 years, or longer if evidence arrives later} | {event map bound} `[A]` |
| **Partition seed** | {8–12 months} | Pooled study, confirmed |
| **Reserve stance** | {user's choice} — ⭐ context, not instruction | Pooled study: no timing edge |
| **Multiplier caps** | **Long ≤6× · swing ≤{2× S1 / 3× S2–S3}** · ⛔ dip-side only | `[A]` inherited, not measured |

---

## 3. {TICKER} — VALUATION BANDS

**Anchor:** {forward EPS | FCF/share} = **{value}** on a **{NTM | FY20XX}** basis `[C]`

```
{Show the anchor's arithmetic: reported figure → one-offs removed → projection}
```

⚠️ **Basis:** every multiple below is on the **{NTM | FY20XX}** basis. ⛔ Never compare against a
multiple on a different basis.

| Price | Implied multiple ({basis}) | Band |
|---|---|---|
| < ${x} | < {n}× | Extreme bear |
| ${x}–${y} | {n}–{m}× | Bear |
| ${y}–${z} | | Base |
| ${z}+ | | Bull |

**Re-derive only** after an anchor change or a C4/C5 thesis change — ⛔ never because price moved.
⛔ Never re-derive downward and call the lower price attractive.

---

## 4. {TICKER} — THRESHOLDS

| Rule | Value |
|---|---|
| **Head start fires** | {S2/S3: price ≤ bear-band ceiling AND (avg > ceiling OR no holdings)} · {S1: default OFF, or only ≤ ${deep level}} |
| **Head start blocked** | Price above threshold (any average), or avg already at/below it |
| **Single-day trigger** | **>10% down** → mandatory cause check |
| **Cumulative trigger** | **~20% below** tracker open → same check |
| **Multiplier caps** | See §2 |

⚠️ **The head start is a valuation bet, never a drawdown bet.** ⛔ Never cite the simulation as
support. {S1 cards: state the 19-of-20 finding and this stock's own row here.}

---

## 5. {TICKER} — EVENT MAP

| # | Date | The yes/no question | What a NO means |
|---|---|---|---|
| EV1 | {date} `[V]`/`[A]` | | |
| EV2 | {10-Q, ~1 week later} `[A]` | ⭐ What does the filing say the call didn't? | |

**Undated triggers:** {U1…Un}

---

## 6. {TICKER} — CAUSE TAXONOMY

| Code | For {TICKER}, looks like |
|---|---|
| **C1** Broad selloff | |
| **C2** Sector rotation | |
| **C3** Miss that doesn't matter | |
| **C4** Miss that does | |
| **C5** Structural break (Door B) | |

**Worked example:** {two same-day events pointing in opposite directions — classify each, then net}

**Explicitly not signals:** {list}

---

## 7. {TICKER} — SCORECARD REFERENCE

⚠️ Reference values at build date, not current. **Load-bearing metrics:** {list, highest first}

⭐ **Constructed metric:** {name} = {numerator} ÷ {denominator} ≈ **{value}** `[C]`

---

## 8. {TICKER} — FUNDING PROFILE

From the pooled large-cap study `[V]` — ⛔ not {TICKER}-specific.

| Swing length | Peak single day | Cleared within 21 trading days |
|---|---|---|
| 5D | 24.4% (up to 48%) | 91.6% |
| 10D | 16.5% | 92.1% |
| 15D | 12.6% | 92.1% |
| 20D | 9.9% | 91.7% |
| 25D | 8.1% | 88.8% |

⭐ Pick by what can be funded on one day. No return difference was found between lengths.

---

## 9. {TICKER} — THE TWO DOORS

**Door A — confirmed:** {list}
**Door B — broken:** {list}
⭐ **The most dangerous combination:** {the pairing that matters more than any single item}

---

## 10. {TICKER} — STANDING INTERROGATIONS

{I1…In — the questions that never resolve at one event}

---

## 11. {TICKER} — WHAT THIS CARD DROPPED

For detail beyond this card, go to the Layer 1 artifact: {list what was compressed out}.

---

## 12. {TICKER} — HONEST LIMITS

- ⛔ "Already down a lot, so downside is limited" does not hold — there is no floor.
- The conviction gate is untestable by construction.
- Pooled-study figures describe the class, not this stock.
- {stock-specific limits, and every `[A]` that matters}
